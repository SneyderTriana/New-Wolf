<?php
// Este archivo contiene funciones para la cabecera (Headerb) y la barra lateral (Side) de la aplicación.
// Es CRÍTICO que este archivo se incluya usando 'require_once' o 'include_once' en tu script principal
// para evitar el error "Cannot redeclare function".
//
// Requiere que la conexión a la base de datos ($mysqli) esté establecida
// y que session_start() se haya llamado en el script principal (ej. index.php).

/**
 * Define la función Headerb para la cabecera de la aplicación.
 *
 * @param mysqli $mysqli Objeto de conexión a la base de datos.
 * @return void
 */
function Headerb(mysqli $mysqli): void
{
  // Asegura que el usuario esté logueado y que $_SESSION['id'] esté definido.
  $current_user_id = $_SESSION['id'] ?? null;
  $is_logged_in = $_SESSION['loggedin'] ?? false; // Asume una variable de sesión 'loggedin'
  $cuantas = 0; // Inicializa el contador de notificaciones.
  $notifications = []; // Inicializa el array de notificaciones.

  // Procede con las consultas de BD solo si hay un ID de usuario en sesión,
  // el usuario está logueado y la conexión mysqli es válida.
  if ($current_user_id !== null && $is_logged_in && $mysqli instanceof mysqli && !$mysqli->connect_errno) {
    // Prepara la consulta para obtener notificaciones no leídas.
    $stmt_noti = $mysqli->prepare("SELECT id_not, user1, tipo, id_pub FROM notificaciones WHERE user2 = ? AND leido = '0' ORDER BY id_not DESC");

    if ($stmt_noti) {
      $stmt_noti->bind_param("i", $current_user_id);
      $stmt_noti->execute();
      $result_noti = $stmt_noti->get_result();
      $cuantas = $result_noti->num_rows;
      $notifications = $result_noti->fetch_all(MYSQLI_ASSOC);
      $stmt_noti->close();
    } else {
      error_log("Error al preparar el statement de notificaciones en Headerb: " . $mysqli->error);
    }
  }
?>
    <li class="dropdown user user-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
      <img src="avatars/<?php echo htmlspecialchars($_SESSION['avatar'] ?? 'default.jpg'); ?>" class="user-image" alt="User Image">
      <span class="hidden-xs"><?php echo htmlspecialchars(ucwords($_SESSION['usuario'] ?? 'Invitado')); ?></span>
    </a>
    <ul class="dropdown-menu">
      <li class="user-header">
      <img src="avatars/<?php echo htmlspecialchars($_SESSION['avatar'] ?? 'default.jpg'); ?>" class="img-circle" alt="User Image">

      <p>
      <?php echo htmlspecialchars(ucwords($_SESSION['usuario'] ?? 'Invitado')); ?>
      <small>Miembro desde Mayo 31</small> </p>
      </li>
      <li class="user-body">
      <div class="row">
      <div class="col-xs-6 text-center">
        <a href="#">Seguidores</a>
      </div>
      <div class="col-xs-6 text-center">
        <a href="#">Seguidos</a>
      </div>
      </div>
      </li>
      <li class="user-footer">
      <div class="pull-left">
      <a href="editarperfil.php?id=<?php echo htmlspecialchars($_SESSION['id'] ?? '');?>" class="btn btn-default btn-flat">Editar perfil</a>
      </div>
      <div class="pull-right">
      <a href="logout.php" class="btn btn-default btn-flat">Cerrar sesión</a>
      </div>
      </li>
    </ul>
    </li>
    <li>
    <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
    </li>
    </ul>
  </div>

  </nav>
  </header>
<?php
} // Fin de la función Headerb

/**
 * Define la función Side para la barra lateral de la aplicación.
 *
 * @return void
 */
function Side(): void
{
  $avatar = $_SESSION['avatar'] ?? 'default.jpg';
  $usuario = $_SESSION['usuario'] ?? 'Invitado';
?>


  </aside>
<?php
} // Fin de la función Side
?>