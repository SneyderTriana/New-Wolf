<!-- Enlace al archivo de estilos CSS -->
<link rel="stylesheet" href="../assets/styles/style.css">

<?php
// Se incluye el archivo que define rutas absolutas del proyecto
require_once __DIR__ . '/../config/addressDocument.php';
// Se incluye la cabecera común del sitio web
require_once HEADER;

// ✅ Evita duplicar session_start()
if (session_status() === PHP_SESSION_NONE) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start(); // ✅ Solo se ejecuta si aún no hay una sesión activa
    }

}

// Incluye conexión a la base de datos (ajusta si usas mysqli procedural u OOP)
include __DIR__ . '/../config/conexion_mysqli_oop.php'; // o _proc.php

// Verifica que el usuario esté logueado
$current_user_id = $_SESSION['id'] ?? null;
$is_logged_in = $_SESSION['loggedin'] ?? false;

$cuantas = 0;
$notifications = [];

if ($current_user_id && $is_logged_in && $mysqli instanceof mysqli && !$mysqli->connect_errno) {
    // Consulta notificaciones no leídas
    $stmt_noti = $mysqli->prepare("SELECT id_not, user1, tipo, id_pub FROM notificaciones WHERE user2 = ? AND leido = '0' ORDER BY id_not DESC");
    if ($stmt_noti) {
        $stmt_noti->bind_param("i", $current_user_id);
        $stmt_noti->execute();
        $result_noti = $stmt_noti->get_result();
        $cuantas = $result_noti->num_rows;
        $notifications = $result_noti->fetch_all(MYSQLI_ASSOC);
        $stmt_noti->close();
    }
}
?>

<ul class="notification-list">
    <?php
    // Mostrar notificaciones si hay
    if ($cuantas > 0) {
        foreach ($notifications as $no) {
            $userNameNoti = 'Usuario Desconocido';

            if ($mysqli instanceof mysqli && !$mysqli->connect_errno && $is_logged_in) {
                $stmt_users = $mysqli->prepare("SELECT username FROM usuarios WHERE id_use = ?");
                if ($stmt_users) {
                    $stmt_users->bind_param("i", $no['user1']);
                    $stmt_users->execute();
                    $result_users = $stmt_users->get_result();
                    if ($result_users->num_rows > 0) {
                        $usa = $result_users->fetch_assoc();
                        $userNameNoti = $usa['username'];
                    }
                    $stmt_users->close();
                }
            }
            ?>
            <div class="contenedor-form" style="margin: 70px auto 0 auto;">
                <li>
                    <a href="publicacion.php?id=<?php echo htmlspecialchars($no['id_pub']); ?>">
                        <i class="fa fa-users text-aqua"></i>
                        El usuario <strong><?php echo htmlspecialchars($userNameNoti); ?></strong>
                        <?php echo htmlspecialchars($no['tipo']); ?> tu publicación
                    </a>
                </li>
            </div>
            <?php
        }
    } else {
        echo '            <div class="contenedor-form" style="margin: 70px auto 0 auto;">
        <li><a href="#"><i class="fa fa-info-circle"></i> No tienes nuevas notificaciones</a></li>
        </div>';
    }
    ?>
</ul>
<div class="contenedor-form" style="margin: 70px auto 0 auto;">
    <div class="box danger-box">
        <div class="box-header">
            <h3 class="box-title">Solicitudes de amistad</h3>
        </div>
        <div class="box-body user-list-items">
            <p>No hay nuevas solicitudes.</p>
        </div>
    </div>
</div>