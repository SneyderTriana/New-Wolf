<?php
require_once __DIR__ . '/../config/conexion_mysqli_proc.php';

if (isset($_GET['id'])) {
 $id = intval($_GET['id']);
 $stmt = $conexion->prepare("SELECT img FROM articulos WHERE id = ?");
 $stmt->bind_param("i", $id);
 $stmt->execute();
 $stmt->store_result();
 $stmt->bind_result($imagen);

 if ($stmt->fetch()) {
  header("Content-Type: image/jpeg");
  echo $imagen;
 } else {
  http_response_code(404);
  echo "Imagen no encontrada";
 }

 $stmt->close();
} else {
 http_response_code(400);
 echo "ID inválido";
}
?>
