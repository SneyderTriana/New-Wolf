<?php
// Iniciar sesión y mostrar errores
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir configuración y conexión
require_once __DIR__ . '/../config/addressDocument.php';
require_once __DIR__ . '/../config/conexion_mysqli_oop.php';

header('Content-Type: application/json');

// Validar conexión
if (!isset($mysqli) || $mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error de conexión a la base de datos."]);
    exit;
}

// Validar datos de sesión y POST
$id_usuario_sesion = $_SESSION['id'] ?? null;
$comentario_contenido = trim($_POST['comentario'] ?? '');
$id_publicacion = isset($_POST['publicacion']) ? (int)$_POST['publicacion'] : null;

if ($id_usuario_sesion === null) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
    exit;
}
if (empty($comentario_contenido) || !$id_publicacion) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Faltan datos del comentario o publicación."]);
    exit;
}

// Insertar comentario
$stmt = $mysqli->prepare("INSERT INTO comentarios (usuario, comentario, fecha, publicacion) VALUES (?, ?, NOW(), ?)");
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Error SQL: " . $mysqli->error]);
    exit;
}
$stmt->bind_param("isi", $id_usuario_sesion, $comentario_contenido, $id_publicacion);
if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => "Error al insertar: " . $stmt->error]);
    exit;
}
$stmt->close();

// Obtener usuario
$stmt_user = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
$stmt_user->bind_param("i", $id_usuario_sesion);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$usuario_info = $result_user->fetch_assoc();
$stmt_user->close();

$nombre_usuario = htmlspecialchars($usuario_info['usuario'] ?? 'Usuario');
$avatar = htmlspecialchars($usuario_info['avatar'] ?? 'default.jpg');
$comentario = htmlspecialchars($comentario_contenido);
$fecha = date('d-m-Y H:i:s');

// Ruta correcta para avatares (asegúrate que AVATAR esté definido en addressDocument.php)
$avatar_path = defined('AVATAR') ? AVATAR : 'avatars'; // fallback

// Generar HTML
$comment_html = '
<div class="box-comment">
    <img class="img-circle img-sm" src="' . $avatar_path . '/' . $avatar . '" alt="Avatar">
    <div class="comment-text">
        <span class="username">' . $nombre_usuario . '
            <span class="text-muted pull-right">' . $fecha . '</span>
        </span>
        ' . $comentario . '
    </div>
</div>';

echo json_encode(["status" => "success", "html" => $comment_html]);
exit;
