
 <header class="content header"> <!-- Encabezado principal con contenido -->
  <section class="image-gallery"> <!-- Galería de imágenes -->
 <img src="<?= IMAGEN ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN1 ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN2 ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN3 ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN1 ?>" alt="Imagen de galer\u00EDa">
 <img src="<?= IMAGEN2 ?>" alt="Imagen de galer\u00EDa">
  </section>
 </header>

</body>