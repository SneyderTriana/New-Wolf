<?php
require_once __DIR__ . '/../config/conexion_mysqli_proc.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
 $descripcion = mysqli_real_escape_string($conexion, $_POST['descripcion']);
 $precio = floatval($_POST['precio']);

 // Carpeta de destino para subir la imagen
 $carpetaDestino = __DIR__ . '/productos/img/';

 // Verificar si se subió una imagen
 if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
  $nombreImagen = basename($_FILES['img']['name']);
  $rutaCompleta = $carpetaDestino . $nombreImagen;

  // Mover la imagen a la carpeta
  if (move_uploaded_file($_FILES['img']['tmp_name'], $rutaCompleta)) {
 // Guardar solo el nombre del archivo en la BD
 $stmt = $conexion->prepare("INSERT INTO articulos (nombre, descripcion, precio, img) VALUES (?, ?, ?, ?)");
 $stmt->bind_param("ssds", $nombre, $descripcion, $precio, $nombreImagen);

 if ($stmt->execute()) {
  echo "<script>alert('Producto agregado exitosamente'); window.location.href='tienda.php';</script>";
 } else {
  echo "Error al guardar el producto: " . $stmt->error;
 }

 $stmt->close();
  } else {
 echo "Error al mover la imagen al servidor.";
  }
 } else {
  die("Error: Imagen no cargada correctamente.");
 }

 $conexion->close();
} else {
 echo "Acceso no permitido.";
}
?>
