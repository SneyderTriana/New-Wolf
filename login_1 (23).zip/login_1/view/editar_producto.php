<?php
require_once __DIR__ . '/../config/addressDocument.php';
include __DIR__ . '/../config/conexion_mysqli_proc.php';
require_once HEADER;

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
  echo "<script>alert('ID de producto inválido'); window.location.href='tienda.php';</script>";
  exit;
}

// Obtener datos actuales del producto
$stmt = $conexion->prepare("SELECT nombre, precio, descripcion, img FROM articulos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<script>alert('Producto no encontrado'); window.location.href='tienda.php';</script>";
  exit;
}

$producto = $result->fetch_assoc();
$stmt->close();

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nuevoNombre = $_POST['nombre'];
  $nuevoPrecio = $_POST['precio'];
  $nuevaDescripcion = $_POST['descripcion'];
  $imagenActual = $producto['img'];

  // Si se sube nueva imagen
  if (!empty($_FILES['img']['name'])) {
    $imgNombre = basename($_FILES['img']['name']);
    $rutaDestino = __DIR__ . "/productos/img/" . $imgNombre;

    if (move_uploaded_file($_FILES['img']['tmp_name'], $rutaDestino)) {
      // Eliminar la imagen anterior
      $rutaAnterior = __DIR__ . "/productos/img/" . $imagenActual;
      if (file_exists($rutaAnterior)) unlink($rutaAnterior);
      $imagenActual = $imgNombre;
    }
  }

  $update = $conexion->prepare("UPDATE articulos SET nombre = ?, precio = ?, descripcion = ?, img = ? WHERE id = ?");
  $update->bind_param("sdssi", $nuevoNombre, $nuevoPrecio, $nuevaDescripcion, $imagenActual, $id);

  if ($update->execute()) {
    echo "<script>alert('Producto actualizado correctamente'); window.location.href='tienda.php';</script>";
    exit;
  } else {
    echo "<script>alert('Error al actualizar');</script>";
  }

  $update->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar producto</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <h3>Editar producto</h3>
  <form method="POST" enctype="multipart/form-data" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Nombre</label>
      <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($producto['nombre']); ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Precio</label>
      <input type="number" step="0.01" name="precio" class="form-control" value="<?php echo $producto['precio']; ?>" required>
    </div>
    <div class="col-12">
      <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="4" required><?php echo htmlspecialchars($producto['descripcion']); ?></textarea>
    </div>
    <div class="col-12">
      <label class="form-label">Imagen actual</label><br>
      <img src="productos/img/<?php echo $producto['img']; ?>" width="150">
    </div>
    <div class="col-12">
      <label class="form-label">Cambiar imagen (opcional)</label>
      <input type="file" name="img" class="form-control" accept="image/*">
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Guardar cambios</button>
      <a href="tienda.php" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</div>
</body>
</html>
