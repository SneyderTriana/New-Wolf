<?php
 if (session_status() === PHP_SESSION_NONE) {
    session_start(); // ✅ Solo se ejecuta si aún no hay una sesión activa
}


unset($_SESSION['usuario']);
unset($_SESSION['id']);

session_destroy();

header("Location: login.php");
?>