<?php
// Incluye archivos de configuración y cabecera
require_once __DIR__ . '/../config/addressDocument.php';
include __DIR__ . '/../config/conexion_mysqli_proc.php';
require_once HEADER;
require_once PRESENTACION;

// Activa el reporte de errores para depuración (SOLO EN DESARROLLO)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Maneja la eliminación de productos
if (isset($_GET['eliminar'])) {
    $idEliminar = intval($_GET['eliminar']);
    // Prepara y ejecuta la consulta para obtener la imagen del producto
    $stmt = $conexion->prepare("SELECT img FROM articulos WHERE id = ?");
    $stmt->bind_param("i", $idEliminar);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($imagen);
        $stmt->fetch();
        $rutaImagen = __DIR__ . "/productos/img/" . $imagen;
        $stmt->close();

        // Prepara y ejecuta la consulta para eliminar el producto de la base de datos
        $stmt = $conexion->prepare("DELETE FROM articulos WHERE id = ?");
        $stmt->bind_param("i", $idEliminar);
        if ($stmt->execute()) {
            // Elimina el archivo de imagen si existe
            if (file_exists($rutaImagen)) {
                unlink($rutaImagen);
            }
            // Muestra alerta de éxito con SweetAlert2 y redirige
            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: '¡Eliminado!',
                        text: 'Producto eliminado exitosamente.',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.href='tienda.php';
                    });
                  </script>";
            exit;
        } else {
            // Muestra alerta de error si la eliminación de la DB falla
            echo "<script>
                    Swal.fire('Error', 'Error al eliminar el producto de la base de datos.', 'error');
                  </script>";
        }
    } else {
        // Muestra alerta si el producto no se encuentra
        echo "<script>
                Swal.fire('Advertencia', 'Producto no encontrado.', 'warning');
              </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda de Productos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="/login_1/assets/styles/style.css">
    
    <style>
        /* Variables CSS (asegúrate de que estas estén definidas en tu style.css o aquí) */

    </style>
</head>

<body>

    <nav class="navbar-custom">
        <div class="navbar-inner">
            <a class="cart-link" onclick="consultar_carrito();" style="cursor:pointer;"> 
                <i class="fas fa-shopping-cart"></i> Mi Carrito (<span id="count_carrito">0</span>)
            </a>
        </div>
    </nav>

    <div class="page-wrapper my-4">
        <a href="crear_producto.php" class="btn-success">Agregar nuevo producto</a>
    </div>

    <main class="store-content-wrapper" id="store-main-content"> 
        <div class="page-wrapper">
            <h2 class="store-title">Nuestros Artículos</h2>
            <div class="products-grid">
                <?php
                // Verifica la conexión a la base de datos
                if (!isset($conexion) || $conexion->connect_error) {
                    echo "<p class='text-center'>Error: No se pudo conectar a la base de datos.</p>";
                } else {
                    // Consulta todos los artículos
                    $buscardor = mysqli_query($conexion, "SELECT * FROM articulos");
                    if ($buscardor && mysqli_num_rows($buscardor) > 0) {
                        // Itera sobre los resultados y muestra cada producto
                        while ($resultado = mysqli_fetch_assoc($buscardor)) {
                ?>
                            <div class="product-col">
                                <div class="product-card">
                                    <img src="productos/img/<?php echo htmlspecialchars($resultado['img']); ?>" class="card-img-top"
                                        alt="<?php echo htmlspecialchars($resultado['nombre']); ?>">
                                    <div class="product-info">
                                        <h4><?php echo htmlspecialchars($resultado["nombre"]); ?></h4>
                                        <div class="product-price"><?php echo number_format($resultado["precio"], 2); ?> pesos</div>
                                        <div class="product-actions">
                                            <button class="btn-add-cart" onclick="envia_carrito(
                                                document.getElementById('ref<?php echo $resultado['id']; ?>').value,
                                                document.getElementById('titulo<?php echo $resultado['id']; ?>').value,
                                                document.getElementById('precio<?php echo $resultado['id']; ?>').value,
                                                document.getElementById('cantidad<?php echo $resultado['id']; ?>').value
                                            ); setTimeout(count_carrito, 500);">
                                                Añadir al carrito
                                            </button>
                                            <a href="editar_producto.php?id=<?php echo htmlspecialchars($resultado['id']); ?>" class="btn-warning">Editar</a>
                                            <a href="#" class="btn-danger"
                                                onclick="Swal.fire({
                                                            title: '¿Estás seguro?',
                                                            text: '¡No podrás revertir esto!',
                                                            icon: 'warning',
                                                            showCancelButton: true,
                                                            confirmButtonColor: '#3085d6',
                                                            cancelButtonColor: '#d33',
                                                            confirmButtonText: 'Sí, eliminar',
                                                            cancelButtonText: 'Cancelar'
                                                        }).then((result) => {
                                                            if (result.isConfirmed) {
                                                                window.location.href='?eliminar=<?php echo htmlspecialchars($resultado['id']); ?>';
                                                            }
                                                        }); return false;">Eliminar</a>

                                            <input type="hidden" id="ref<?php echo htmlspecialchars($resultado['id']); ?>" value="<?php echo htmlspecialchars($resultado['id']); ?>">
                                            <input type="hidden" id="precio<?php echo htmlspecialchars($resultado['id']); ?>"
                                                value="<?php echo htmlspecialchars($resultado['precio']); ?>">
                                            <input type="hidden" id="titulo<?php echo htmlspecialchars($resultado['id']); ?>"
                                                value="<?php echo htmlspecialchars($resultado['nombre']); ?>">
                                            <input type="hidden" id="cantidad<?php echo htmlspecialchars($resultado['id']); ?>" value="1">
                                        </div>
                                    </div>
                                </div>
                            </div>
                <?php
                        }
                    } else {
                        // Mensaje si no hay artículos
                        echo "<p class='text-center'>No hay artículos disponibles.</p>";
                    }
                }
                ?>
            </div>
        </div>
    </main>

    <div id="modal_cart" class="modal-custom hidden"> 
        <div class="modal-content-custom">
            <div class="modal-header-custom">
                <h5>Mi carrito</h5>
                <button class="close-modal" onclick="document.getElementById('modal_cart').classList.add('hidden')">×</button>
            </div>
            <div class="modal-body-custom" id="mi_carrito"></div>
            <div class="modal-footer-custom">
                <button onclick="document.getElementById('modal_cart').classList.add('hidden')"
                    class="btn-secondary">Cerrar</button>
                <button onclick="borrar_carrito(); setTimeout(count_carrito, 500);" class="btn-primary">Vaciar carrito</button>
                <a href="confirmar_pago.php" class="btn-success">Proceder al pago</a>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo JS; ?>"></script>

    <script>
        // Función para consultar y mostrar el contenido del carrito en el modal
        function consultar_carrito() {
            // Remueve la clase 'hidden' para hacer visible el modal
            document.getElementById('modal_cart').classList.remove('hidden'); 
            $.ajax({
                data: {},
                type: "POST",
                url: "/login_1/controller/auxiliar/modal_carrito.php",
                success: function (data) {
                    document.getElementById("mi_carrito").innerHTML = data;
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    document.getElementById("mi_carrito").innerHTML =
                        '<p class="text-danger">Error al cargar el carrito.</p>';
                    console.error("Error al consultar carrito:", textStatus, errorThrown);
                },
            });
        }

        // Función para obtener y actualizar el contador de ítems en el carrito
        // MODIFICADO: Ahora espera una respuesta JSON y accede a la propiedad 'count'.
        function count_carrito() {
            $.ajax({
                url: '/login_1/controller/auxiliar/count_carrito.php', 
                type: 'GET', 
                dataType: 'json', // Indica que esperamos una respuesta JSON
                success: function (response) { // Cambiado 'count' a 'response' para mayor claridad
                    if (response && typeof response.count !== 'undefined') {
                        $('#count_carrito').text(response.count); // Accede a la propiedad 'count' del objeto
                    } else {
                        console.error("Respuesta inesperada de count_carrito.php:", response);
                        $('#count_carrito').text('0'); // En caso de respuesta inesperada, muestra 0
                    }
                },
                error: function (xhr, status, error) {
                    console.error("AJAX Error count_carrito:", status, error, xhr.responseText);
                    $('#count_carrito').text('0'); // Muestra 0 en caso de error de AJAX
                }
            });
        }

        // Inicializa el contador del carrito al cargar la página
        $(document).ready(function () {
            count_carrito();
        });

    </script>

    <?php require_once FOOTER; ?>
</body>

</html>