<link rel="stylesheet" href="../assets/styles/style.css">
<?php
// Incluye archivos de configuración y cabecera
require_once __DIR__ . '/../config/addressDocument.php';
require_once HEADER; // Asume que HEADER incluye 'session_start()' con la comprobación PHP_SESSION_NONE
include __DIR__ . '/../config/conexion_mysqli_oop.php'; // Incluye el archivo de conexión a DB

// Muestra todos los errores de PHP (solo para desarrollo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica la conexión a la base de datos
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Error crítico: La conexión a la base de datos no está disponible.");
}

// Asegúrate de que la sesión esté iniciada y que $_SESSION['id'] contenga el ID del usuario
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirecciona si el usuario no ha iniciado sesión.
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

// Define la ruta de avatares para JavaScript (asumiendo que AVATAR es una constante definida en addressDocument.php)
$avatar_path = defined('AVATAR') ? AVATAR : '../avatars'; // Fallback si AVATAR no está definido

// Procesar parámetros GET para el perfil si el ID está presente.
if (isset($_GET['id'])) {
    $id = $_GET['id']; // ID del perfil que se está viendo
    $pag = isset($_GET['perfil']) ? $_GET['perfil'] : 'miactividad';

    // Obtiene información del usuario del perfil (nombre, avatar, etc.)
    // ✅ MODIFICACIÓN: Se añaden las columnas 'acercaDeMi', 'educacion', 'ubicacion', 'habilidades'
    $stmt_user = $mysqli->prepare("SELECT id_use, username, avatar, verificado, privada, acercaDeMi, educacion, ubicacion, habilidades FROM usuarios WHERE id_use = ?");
    $stmt_user->bind_param("i", $id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $use = $result_user->fetch_assoc();
    $stmt_user->close();

    // Redirige si el usuario no existe.
    if (!$use) {
        header("Location: error.php?msg=Usuario no encontrado");
        exit();
    }

    // Obtiene información de la relación de amistad entre el usuario logueado y el perfil visto.
    $stmt_amigos = $mysqli->prepare("SELECT * FROM amigos WHERE (de = ? AND para = ?) OR (de = ? AND para = ?)");
    $stmt_amigos->bind_param("iiii", $_SESSION['id'], $id, $id, $_SESSION['id']);
    $stmt_amigos->execute();
    $result_amigos = $stmt_amigos->get_result();
    $ami = $result_amigos->fetch_assoc();
    $num_amigos = $result_amigos->num_rows;
    $stmt_amigos->close();

    // Bloque de manejo de acciones de amistad (seguir/dejar de seguir) por POST.
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Lógica para enviar solicitud de amistad (seguir).
        if (isset($_POST['seguir'])) {
            $stmt_add = $mysqli->prepare("INSERT INTO amigos (de, para, fecha, estado) VALUES (?, ?, NOW(), '0')");
            $stmt_add->bind_param("ii", $_SESSION['id'], $id);
            if (!$stmt_add->execute()) {
                error_log("Error al enviar solicitud de amistad: " . $stmt_add->error);
            }
            $stmt_add->close();
            header("Location: perfil.php?id=" . $id);
            exit();
        }

        // Lógica para seguir directamente (perfiles no privados).
        if (isset($_POST['seguirdirecto'])) {
            $stmt_add = $mysqli->prepare("INSERT INTO amigos (de, para, fecha, estado) VALUES (?, ?, NOW(), '1')");
            $stmt_add->bind_param("ii", $_SESSION['id'], $id);
            if (!$stmt_add->execute()) {
                error_log("Error al seguir directamente: " . $stmt_add->error);
            }
            $stmt_add->close();
            header("Location: perfil.php?id=" . $id);
            exit();
        }

        // Lógica para dejar de seguir (eliminar relación de amistad).
        if (isset($_POST['dejarseguir'])) {
            $stmt_delete = $mysqli->prepare("DELETE FROM amigos WHERE (de = ? AND para = ?) OR (de = ? AND para = ?)");
            $stmt_delete->bind_param("iiii", $_SESSION['id'], $id, $id, $_SESSION['id']);
            if (!$stmt_delete->execute()) {
                error_log("Error al dejar de seguir: " . $stmt_delete->error);
            }
            $stmt_delete->close();
            header("Location: perfil.php?id=" . $id);
            exit();
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="es">

    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars($use['username']); ?> </title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="stylesheet" href="../assets/styles/light.css">
        <link rel="stylesheet" href="../assets/styles/style.css"> <!-- Aquí se carga tu CSS principal -->
        <link rel="stylesheet" href="../assets/styles/main.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="js/jquery.jscroll.js"></script>
    </head>

    <body>
        <div class="wrapper">

            <div class="content-wrapper">
                <section class="content-section">
                    <div class="row-container">

                        <div class="profile-form-column">
                            <div class="box primary-box" style="margin: 70px;">
                                <div class="box-header">
                                    <h3 class="box-title">Perfil de usuario</h3>
                                </div>
                                <div class="box-body">
                                    <div class="profile-box-body">
                                        <img class="profile-user-img"
                                            src="avatars/<?php echo htmlspecialchars($use['avatar']); ?>"
                                            alt="User profile picture" style="height: 300px; border-radius: 20%;">
                                        <h3 class="profile-username"><?php echo htmlspecialchars($use['username']); ?></h3>

                                        <?php // Muestra el ícono de verificado si aplica.
                                            if ($use['verificado'] != 0) { ?>
                                            <center><span class="icon-verified">✔</span></center>
                                        <?php } ?>

                                        <p class="text-muted-center"></p>


                                        <?php // Sección para seguir/dejar de seguir si no es el perfil propio.
                                            if ($_SESSION['id'] != $id) { ?>
                                            <form action="" method="post">
                                                <?php // Estado: Esperando respuesta (solicitud enviada).
                                                        if ($num_amigos >= 1 && $ami['estado'] == 0) { ?>
                                                    <center>
                                                        <h4>Esperando respuesta</h4>
                                                    </center>
                                                <?php } else { ?>
                                                    <?php // Perfil privado: Opción de enviar solicitud (estado 0) si no hay relación o la relación no está aceptada.
                                                                if ($use['privada'] == 1 && ($num_amigos == 0 || $ami['estado'] == 0)) { ?>
                                                        <input type="submit" class="button button-primary" name="seguir"
                                                            value="Enviar solicitud de amistad">
                                                    <?php } ?>

                                                    <?php // Perfil privado: Opción de dejar de seguir (estado 1) si ya son amigos.
                                                                if ($use['privada'] == 1 && $num_amigos >= 1 && $ami['estado'] == 1) { ?>
                                                        <input type="submit" class="button button-danger" name="dejarseguir"
                                                            value="Dejar de seguir">
                                                    <?php } ?>

                                                    <?php // Perfil público: Opción de Seguir directamente (estado 1).
                                                                if ($use['privada'] == 0 && ($num_amigos == 0 || $ami['estado'] == 0)) { ?>
                                                        <input type="submit" class="button button-primary" name="seguirdirecto"
                                                            value="Seguir">
                                                    <?php } ?>

                                                    <?php // Perfil público: Opción de dejar de seguir.
                                                                if ($use['privada'] == 0 && $num_amigos >= 1 && $ami['estado'] == 1) { ?>
                                                        <input type="submit" class="button button-danger" name="dejarseguir"
                                                            value="Dejar de seguir">
                                                    <?php } ?>
                                                <?php } ?>
                                            </form>
                                        <?php } ?>

                                        <br>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sidebar-column">
                            <div class="tabs-custom">
                                <ul class="nav-tabs">
                                    <li class="<?php echo $pag == 'miactividad' ? 'active' : ''; ?>"><a
                                            href="?id=<?php echo htmlspecialchars($id); ?>&perfil=miactividad">Actividad</a>
                                    </li>
                                    <li class="<?php echo $pag == 'informacion' ? 'active' : ''; ?>"><a
                                            href="?id=<?php echo htmlspecialchars($id); ?>&perfil=informacion">Información</a>
                                    </li>
                                <div class="tab-content">
                                    <div class="scroll-content">
                                        <?php // Controla la visibilidad del contenido según si el perfil es privado y el estado de amistad.
                                            if (
                                                $use['privada'] != 1 ||
                                                ($use['privada'] == 1 && $num_amigos >= 1 && $ami['estado'] == 1) ||
                                                ($_SESSION['id'] == $id)
                                            ) {
                                                $valid_pages = ['miactividad', 'informacion', 'fotos'];
                                                $current_page = in_array($pag, $valid_pages) ? $pag : 'miactividad';

                                                // INICIO: Lógica de publicaciones (anteriormente en miactividad.php)
                                                if ($current_page == 'miactividad') {
                                                    // Lógica para la paginación de publicaciones
                                                    $CantidadMostrar = 5;
                                                    $compag = (int) (!isset($_GET['pag'])) ? 1 : $_GET['pag'];

                                                    // Obtener el total de publicaciones del usuario actual del perfil
                                                    $stmt_total_reg = $mysqli->prepare("SELECT COUNT(*) AS total FROM publicaciones WHERE id_use = ?");
                                                    $stmt_total_reg->bind_param("i", $id); // Usamos $id del perfil visitado
                                                    $stmt_total_reg->execute();
                                                    $result_total_reg = $stmt_total_reg->get_result();
                                                    $totalr = $result_total_reg->fetch_assoc()['total'];
                                                    $stmt_total_reg->close();

                                                    $TotalRegistro = ceil($totalr / $CantidadMostrar);
                                                    $IncrimentNum = (($compag + 1) <= $TotalRegistro) ? ($compag + 1) : 0;
                                                    $offset = ($compag - 1) * $CantidadMostrar;

                                                    // Obtener las publicaciones para la página actual del usuario del perfil
                                                    $stmt_publicaciones = $mysqli->prepare("SELECT id_pub, id_use, contenido, fecha, imagen, likes FROM publicaciones WHERE id_use = ? ORDER BY id_pub DESC LIMIT ?, ?");
                                                    $stmt_publicaciones->bind_param("iii", $id, $offset, $CantidadMostrar); // Usamos $id del perfil visitado
                                                    $stmt_publicaciones->execute();
                                                    $consulta = $stmt_publicaciones->get_result();

                                                    // Mostrar mensaje si no hay publicaciones
                                                    if ($consulta->num_rows === 0) {
                                                        echo "<p style='text-align: center; margin-top: 20px; color: var(--light-grey);'>No hay publicaciones disponibles para este usuario.</p>";
                                                    }

                                                    // Bucle para mostrar cada publicación
                                                    while ($lista = $consulta->fetch_assoc()) {
                                                        $userid_pub = $lista['id_use']; // ID del usuario que hizo esta publicación
                                                        // Obtener información del usuario que hizo la publicación
                                                        $stmt_usuariob = $mysqli->prepare("SELECT id_use, username, avatar FROM usuarios WHERE id_use = ?");
                                                        $stmt_usuariob->bind_param("i", $userid_pub);
                                                        $stmt_usuariob->execute();
                                                        $use_pub = $stmt_usuariob->get_result()->fetch_assoc();
                                                        $stmt_usuariob->close();

                                                        $fot_ruta = '';
                                                        // Obtener la ruta de la imagen si la publicación tiene una
                                                        if ($lista['imagen'] != 0) {
                                                            $stmt_fotos = $mysqli->prepare("SELECT ruta FROM fotos WHERE publicacion = ?");
                                                            $stmt_fotos->bind_param("i", $lista['id_pub']);
                                                            $stmt_fotos->execute();
                                                            $row_foto = $stmt_fotos->get_result()->fetch_assoc();
                                                            if ($row_foto) {
                                                                $fot_ruta = $row_foto['ruta'];
                                                            }
                                                            $stmt_fotos->close();
                                                        }
                                                ?>
                                                        <!-- Estructura de la caja de publicación -->
                                                        <div class="box box-widget">
                                                            <div class="box-header with-border">
                                                                <div class="user-block">
                                                                    <img class="img-circle" src="avatars/<?php echo htmlspecialchars($use_pub['avatar'] ?? ''); ?>" alt="User Image">
                                                                    <span class="description" onclick="location.href='perfil.php?id=<?php echo htmlspecialchars($use_pub['id_use'] ?? ''); ?>';" style="cursor:pointer;">
                                                                        <?php echo htmlspecialchars($use_pub['username'] ?? ''); ?>
                                                                    </span>
                                                                    <span class="description"><?php echo htmlspecialchars($lista['fecha'] ?? ''); ?></span>
                                                                </div>
                                                                <!-- Puedes añadir botones de acción aquí si los necesitas, como un menú de 3 puntos -->
                                                            </div>
                                                            <div class="box-body">
                                                                <p><?php echo htmlspecialchars($lista['contenido'] ?? ''); ?></p>
                                                                <?php if ($lista['imagen'] != 0 && !empty($fot_ruta)) { ?>
                                                                    <img src="publicaciones/<?php echo htmlspecialchars($fot_ruta); ?>" alt="Publicación con imagen">
                                                                <?php } ?>
                                                                <?php
                                                                // Obtener el número de comentarios para esta publicación
                                                                $stmt_num_comen = $mysqli->prepare("SELECT COUNT(*) AS num_comen FROM comentarios WHERE publicacion = ?");
                                                                $stmt_num_comen->bind_param("i", $lista['id_pub']);
                                                                $stmt_num_comen->execute();
                                                                $numcomen = $stmt_num_comen->get_result()->fetch_assoc()['num_comen'];
                                                                $stmt_num_comen->close();
                                                                ?>
                                                                <ul class="list-inline">
                                                                    <li>
                                                                        <a href="#" class="link-black text-sm like" id="<?php echo htmlspecialchars($lista['id_pub']); ?>">
                                                                            <i class="fa fa-thumbs-o-up"></i>
                                                                            <?php
                                                                                // Lógica para mostrar "Me gusta" o "No me gusta"
                                                                                echo ($lista['likes'] > 0 ? "No me gusta" : "Me gusta");
                                                                            ?>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <span class="pull-right text-muted" id="likes_<?php echo htmlspecialchars($lista['id_pub']); ?>">
                                                                            (<?php echo htmlspecialchars($lista['likes'] ?? 0); ?>)
                                                                        </span>
                                                                    </li>
                                                                    <li>
                                                                        <span class="text-muted"><i class="fa fa-comments-o"></i> Comentarios
                                                                            (<?php echo htmlspecialchars($numcomen); ?>)</span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div class="box-footer box-comments">
                                                                <?php
                                                                // Obtener los últimos 2 comentarios
                                                                $stmt_comentarios = $mysqli->prepare("SELECT id_com, usuario, comentario, fecha FROM comentarios WHERE publicacion = ? ORDER BY id_com DESC LIMIT 2");
                                                                $stmt_comentarios->bind_param("i", $lista['id_pub']);
                                                                $stmt_comentarios->execute();
                                                                $result_comentarios = $stmt_comentarios->get_result();
                                                                while ($com = $result_comentarios->fetch_assoc()) {
                                                                    // Obtener información del usuario que hizo el comentario
                                                                    $stmt_usuarioc = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
                                                                    $stmt_usuarioc->bind_param("i", $com['usuario']);
                                                                    $stmt_usuarioc->execute();
                                                                    $usec = $stmt_usuarioc->get_result()->fetch_assoc();
                                                                    $stmt_usuarioc->close();
                                                                ?>
                                                                    <div class="box-comment">
                                                                        <img class="img-circle img-sm" src="avatars/<?php echo htmlspecialchars($usec['avatar'] ?? ''); ?>" alt="Avatar">
                                                                        <div class="comment-text">
                                                                            <span class="username">
                                                                                <?php echo htmlspecialchars($usec['username'] ?? ''); ?>
                                                                                <span class="text-muted pull-right"><?php echo htmlspecialchars($com['fecha'] ?? ''); ?></span>
                                                                            </span>
                                                                            <?php echo htmlspecialchars($com['comentario'] ?? ''); ?>
                                                                        </div>
                                                                    </div>
                                                                <?php }
                                                                $stmt_comentarios->close(); ?>
                                                                <?php if ($numcomen > 2) { ?>
                                                                    <br>
                                                                    <center><span onclick="location.href='publicacion.php?id=<?php echo htmlspecialchars($lista['id_pub']); ?>';" style="cursor:pointer;">Ver todos los comentarios</span></center>
                                                                <?php } ?>
                                                                <div id="nuevocomentario<?php echo htmlspecialchars($lista['id_pub']); ?>"></div>
                                                                <br>
                                                                <form method="post" action="">
                                                                    <label id="record-<?php echo htmlspecialchars($lista['id_pub']); ?>" style="width: 100%;">
                                                                        <input type="text" class="enviar-btn form-control input-sm" placeholder="Escribe un comentario" name="comentario" id="comentario-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                                                                    </label>
                                                                </form>
                                                            </div>
                                                        </div><br><br>
                                                <?php }
                                                    $stmt_publicaciones->close();
                                                    // Enlace para la siguiente página de publicaciones
                                                    if ($IncrimentNum > 0) {
                                                        echo "<a href=\"perfil.php?id=" . htmlspecialchars($id) . "&perfil=miactividad&pag=$IncrimentNum\" class='custom-btn custom-btn-primary'>Siguiente</a>";
                                                    }
                                                }
                                                // FIN: Lógica de publicaciones
                                                else if ($current_page == 'informacion') {
                                                    // ✅ INICIO: Contenido de la pestaña de información dinámico
                                                ?>
                                                    <div class="info-box" style="margin-top: 20px; width: 100%;">
                                                        <div class="info-box-header">
                                                            <h3 class="info-box-title">Acerca de mí</h3>
                                                        </div>
                                                        <div class="info-box-body">
                                                            <strong><i class="icon-book"></i> Educación</strong>
                                                            <p class="text-muted">
                                                                <?php echo htmlspecialchars($use['educacion'] ?? 'No especificado'); ?>
                                                            </p>
                                                            <hr>
                                                            <strong><i class="icon-map-marker"></i> Ubicación</strong>
                                                            <p class="text-muted">
                                                                <?php echo htmlspecialchars($use['ubicacion'] ?? 'No especificado'); ?>
                                                            </p>
                                                            <hr>
                                                            <strong><i class="icon-pencil"></i> Habilidades</strong>
                                                            <p>
                                                                <?php
                                                                // Divide la cadena de habilidades por comas y muestra cada una como una etiqueta
                                                                $habilidades = htmlspecialchars($use['habilidades'] ?? '');
                                                                if (!empty($habilidades)) {
                                                                    $habilidades_array = explode(',', $habilidades);
                                                                    foreach ($habilidades_array as $habilidad) {
                                                                        echo '<span class="tag">' . trim($habilidad) . '</span> ';
                                                                    }
                                                                } else {
                                                                    echo 'No especificadas';
                                                                }
                                                                ?>
                                                            </p>
                                                            <hr>
                                                        </div>
                                                    </div>
                                                <?php
                                                    // ✅ FIN: Contenido de la pestaña de información dinámico
                                                } else if ($current_page == 'fotos') {
                                                    // Aquí iría el contenido de la pestaña de fotos
                                                    /*echo "<p style='text-align: center; margin-top: 20px; color: var(--light-grey);'>Contenido de las fotos del perfil.</p>";*/
                                                }
                                            } else {
                                                ?>
                                            <center>
                                                <h2>Este perfil es privado, envía una solicitud.</h2>
                                            </center>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>

                            <div class="box danger-box">
                                <div class="box-header">
                                    <!--<h3 class="box-title">Solicitudes de amistad</h3>-->
                                </div>
                                <div class="box-body user-list-items">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- ✅ ELIMINADO: Este bloque info-box duplicado y estático ha sido movido y hecho dinámico dentro de la pestaña 'informacion' -->
            <!-- <div class="info-box">
                <div class="info-box-header">
                    <h3 class="info-box-title">Acerca de mi</h3>
                </div>
                <div class="info-box-body">
                    <strong><i class="icon-book"></i> Educacion</strong>
                    <p class="text-muted">
                        B.S. in Computer Science from the University of Tennessee at Knoxville
                    </p>
                    <hr>
                    <strong><i class="icon-map-marker"></i> Ubicacion</strong>
                    <p class="text-muted">Malibu, California</p>
                    <hr>
                    <strong><i class="icon-pencil"></i> Habilidades</strong>
                    <p>
                        <span class="tag tag-danger">UI Design</span>
                        <span class="tag tag-success">Coding</span>
                        <span class="tag tag-info">Javascript</span>
                        <span class="tag tag-warning">PHP</span>
                        <span class="tag tag-primary">Node.js</span>
                    </p>
                    <hr>
                </div>
            </div> -->

            <aside class="control-sidebar">
                <ul class="control-sidebar-nav">
                    <li><a href="#control-sidebar-home-tab" data-toggle="tab"><span class="icon-home"></span></a></li>
                    <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><span class="icon-settings"></span></a>
                    </li>
                </ul>
                <div class="control-sidebar-content">
                    <!-- SECCIONES ELIMINADAS: Actividad Reciente, Progreso de Tareas, Configuración General, Configuración de Chat -->
                    <!-- El contenido de las pestañas ahora estará vacío si no se añade otra cosa -->
                    <div class="tab-pane-content" id="control-sidebar-home-tab">
                        <!-- Contenido de Actividad Reciente y Progreso de Tareas iría aquí si se añade -->
                    </div>
                    <!--<div class="tab-pane-content" id="control-sidebar-stats-tab">Contenido de la pestaña de estadísticas-->
                    </div>
                    <div class="tab-pane-content" id="control-sidebar-settings-tab">
                        <!-- Contenido de Configuración General y Configuración de Chat iría aquí si se añade -->
                    </div>
                </div>
            </aside>
            <div class="control-sidebar-bg"></div>
        </div>
        <!-- jQuery y jscroll se mantienen al final del body -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="js/jquery.jscroll.js"></script>

        <!-- JavaScript EMBEBIDO PARA LIKES Y COMENTARIOS -->
        <script type="text/javascript">
            // Define la ruta base para avatares para ser usada en JavaScript
            const AVATAR_PATH = "<?php echo $avatar_path; ?>";

            $(document).ready(function () {
                // Manejador para el envío de comentarios al presionar Enter
                $(".enviar-btn").keypress(function (event) {
                    if (event.which == 13) {
                        event.preventDefault();

                        var getpID = $(this).parent().attr('id').replace('record-', '');
                        var comentario = $("#comentario-" + getpID).val();
                        var publicacion = getpID;

                        if (comentario.trim() === '') {
                            alert('Debes añadir un comentario.');
                            return false;
                        }

                        $.ajax({
                            type: "POST",
                            url: "agregarcomentario.php", // Ruta relativa a perfil.php
                            data: {
                                comentario: comentario,
                                publicacion: publicacion
                            },
                            dataType: "json",
                            success: function (response) {
                                if (response.status === "success") {
                                    $('#nuevocomentario' + getpID).append(response.html);
                                    $("#comentario-" + getpID).val('');
                                } else {
                                    alert("Error al agregar el comentario: " + response.message);
                                    console.error("Error del servidor (Comentario):", response.message);
                                }
                            },
                            error: function (xhr) {
                                console.error("Error AJAX (Comentario):", xhr.responseText);
                                alert("Error al agregar el comentario. Intenta nuevamente.");
                            }
                        });
                        return false;
                    }
                });

                // Manejador de clics para los botones de "Me gusta"
                $('.like').on('click', function(e) {
                    e.preventDefault();

                    var publicacionId = $(this).attr('id');
                    var $likeSpan = $('#likes_' + publicacionId);
                    var $likeLink = $(this);

                    $.ajax({
                        type: "POST",
                        url: "megusta.php", // Ruta relativa a perfil.php
                        data: { publicacion: publicacionId },
                        dataType: "json",
                        success: function(response) {
                            if (response.status === "success") {
                                $likeSpan.text('(' + response.likes + ')');
                                if (response.action === "liked") {
                                    $likeLink.html('<i class="fa fa-thumbs-o-up"></i> No me gusta');
                                } else if (response.action === "disliked") {
                                    $likeLink.html('<i class="fa fa-thumbs-o-up"></i> Me gusta');
                                }
                            } else {
                                alert("Error al procesar el like: " + response.message);
                                console.error("Error del servidor (Likes):", response.message);
                            }
                        },
                        error: function(xhr) {
                            console.error("Error AJAX (Likes):", xhr.responseText);
                            alert("Error al procesar el like. Intenta nuevamente.");
                        }
                    });
                });
            });
        </script>

        <script src="../assets/js/custom-tabs.js"></script>
        <script src="../assets/js/custom-sidebar.js"></script>
    </body>

    </html>
    <?php
} else {
    echo "<p style='text-align: center; color: red;'>Error: No se ha especificado un ID de usuario para el perfil.</p>";
}
?>