<!-- Enlace al archivo de estilos CSS -->
<link rel="stylesheet" href="../assets/styles/style.css">

<!-- ✅ Agregamos jQuery antes de cualquier uso del símbolo $ -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php
require_once __DIR__ . '/../config/addressDocument.php';
require_once HEADER;
include __DIR__ . '/../config/conexion_mysqli_oop.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Verificar ID de publicación
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Publicación no válida.");
}

$id_pub = (int) $_GET['id'];
$avatar_path = AVATAR;

// Obtener la publicación
$stmt_pub = $mysqli->prepare("SELECT id_pub, id_use, contenido, fecha, imagen, likes FROM publicaciones WHERE id_pub = ?");
$stmt_pub->bind_param("i", $id_pub);
$stmt_pub->execute();
$pub = $stmt_pub->get_result()->fetch_assoc();
$stmt_pub->close();

if (!$pub) {
    die("Publicación no encontrada.");
}

// Obtener info del autor
$stmt_autor = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
$stmt_autor->bind_param("i", $pub['id_use']);
$stmt_autor->execute();
$autor = $stmt_autor->get_result()->fetch_assoc();
$stmt_autor->close();

// Obtener imagen si tiene
$fot_ruta = '';
if ($pub['imagen'] != 0) {
    $stmt_foto = $mysqli->prepare("SELECT ruta FROM fotos WHERE publicacion = ?");
    $stmt_foto->bind_param("i", $id_pub);
    $stmt_foto->execute();
    $fot_ruta = $stmt_foto->get_result()->fetch_assoc()['ruta'] ?? '';
    $stmt_foto->close();
}
?>

<script type="text/javascript">
const AVATAR_PATH = "<?php echo $avatar_path; ?>";

$(document).ready(function () {
    // Evento enter para enviar comentario
    $(".enviar-btn").keypress(function (event) {
        if (event.which == 13) {
            event.preventDefault();

            var publicacion = <?php echo $id_pub; ?>;
            var comentario = $("#comentario-<?php echo $id_pub; ?>").val();

            if (comentario.trim() === '') {
                alert('Debes añadir un comentario.');
                return false;
            }

            $.ajax({
                type: "POST",
                url: "agregarcomentario.php",
                data: {
                    comentario: comentario,
                    publicacion: publicacion
                },
                dataType: "json",
                success: function (response) {
                    if (response.status === "success") {
                        $('#nuevocomentario<?php echo $id_pub; ?>').append(response.html);
                        $("#comentario-<?php echo $id_pub; ?>").val('');
                    } else {
                        alert("Error al agregar el comentario: " + response.message);
                    }
                },
                error: function (xhr) {
                    alert("Error al agregar el comentario.");
                    console.error(xhr.responseText);
                }
            });
            return false;
        }
    });
});
</script>

<div class="box box-widget">
    <div class="box-header with-border">
        <div class="user-block">
            <img class="img-circle" src="<?php echo AVATAR . '/' . htmlspecialchars($autor['avatar']); ?>" alt="User Image">
            <span class="description" style="color: #3C8DBC;"><?php echo htmlspecialchars($autor['username']); ?></span>
            <span class="description"><?php echo htmlspecialchars($pub['fecha']); ?></span>
        </div>
    </div>
    <div class="box-body">
        <p><?php echo htmlspecialchars($pub['contenido']); ?></p>
        <?php if (!empty($fot_ruta)) { ?>
            <img src="publicaciones/<?php echo htmlspecialchars($fot_ruta); ?>" width="100%">
        <?php } ?>
        <ul class="list-inline">
            <li><a href="#" class="link-black text-sm like" id="<?php echo $id_pub; ?>"><i class="fa fa-thumbs-o-up"></i> Me gusta</a></li>
            <li><span class="pull-right text-muted" id="likes_<?php echo $id_pub; ?>">(<?php echo $pub['likes']; ?>)</span></li>
        </ul>
    </div>

    <div class="box-footer box-comments">
        <?php
        $stmt_comentarios = $mysqli->prepare("SELECT usuario, comentario, fecha FROM comentarios WHERE publicacion = ? ORDER BY id_com ASC");
        $stmt_comentarios->bind_param("i", $id_pub);
        $stmt_comentarios->execute();
        $result_com = $stmt_comentarios->get_result();

        while ($com = $result_com->fetch_assoc()) {
            $stmt_user = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
            $stmt_user->bind_param("i", $com['usuario']);
            $stmt_user->execute();
            $user = $stmt_user->get_result()->fetch_assoc();
            $stmt_user->close();
        ?>
            <div class="box-comment">
                <img class="img-circle img-sm" src="<?php echo AVATAR . '/' . htmlspecialchars($user['avatar']); ?>" alt="Avatar">
                <div class="comment-text">
                    <span class="username"><?php echo htmlspecialchars($user['username']); ?>
                        <span class="text-muted pull-right"><?php echo htmlspecialchars($com['fecha']); ?></span>
                    </span>
                    <?php echo htmlspecialchars($com['comentario']); ?>
                </div>
            </div>
        <?php }
        $stmt_comentarios->close(); ?>

        <div id="nuevocomentario<?php echo $id_pub; ?>"></div>
        <br>
        <form method="post">
            <label id="record-<?php echo $id_pub; ?>">
                <input type="text" class="enviar-btn form-control input-sm" placeholder="Escribe un comentario" name="comentario" id="comentario-<?php echo $id_pub; ?>">
            </label>
        </form>
    </div>
</div>
