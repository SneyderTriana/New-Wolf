<link rel="stylesheet" href="../assets/styles/style.css">
<?php
require_once __DIR__ . '/../config/addressDocument.php';
require_once HEADER;
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // ✅ Solo se ejecuta si aún no hay una sesión activa
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../controller/UsuarioController.php';

$controller = new UsuarioController();
$datos = $controller->obtenerDatosUsuario();

if (!$datos) {
    echo "<p>Error: No se pudieron obtener los datos del usuario. ¿Has iniciado sesión?</p>";
    exit;
}

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->actualizarPerfil();
    // Puedes recargar para mostrar los nuevos datos
    header("Location: editarperfil.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <style>
        label { display: block; margin-top: 10px; }
        input, textarea, select { width: 100%; max-width: 400px; }
        .avatar-preview { margin-top: 10px; }
    </style>
</head>
<body>
        <div class="contenedor-form">
    <h2>Editar Perfil</h2>

    <form action="editarperfil.php" method="POST" enctype="multipart/form-data">
        <label>Nombre:
            <input type="text" name="nombre" value="<?= htmlspecialchars($datos['nombre']) ?>" required>
        </label>

        <label>Usuario:
            <input type="text" name="username" value="<?= htmlspecialchars($datos['username']) ?>" required>
        </label>

        <label>Correo:
            <input type="email" name="correo" value="<?= htmlspecialchars($datos['correo']) ?>" required>
        </label>

        <label>Género:
            <select name="genero" required>
                <option value="">Seleccionar</option>
                <option value="Masculino" <?= $datos['genero'] === 'Masculino' ? 'selected' : '' ?>>Masculino</option>
                <option value="Femenino" <?= $datos['genero'] === 'Femenino' ? 'selected' : '' ?>>Femenino</option>
                <option value="Otro" <?= $datos['genero'] === 'Otro' ? 'selected' : '' ?>>Otro</option>
            </select>
        </label>

        <label>Fecha de Nacimiento:
            <input type="date" name="fechaNacimiento" value="<?= htmlspecialchars($datos['fechaNacimiento']) ?>">
        </label>

        <label>Acerca de mí:
            <textarea name="acercaDeMi"><?= htmlspecialchars($datos['acercaDeMi']) ?></textarea>
        </label>

        <label>Educación:
            <input type="text" name="educacion" value="<?= htmlspecialchars($datos['educacion']) ?>">
        </label>

        <label>Ubicación:
            <input type="text" name="ubicacion" value="<?= htmlspecialchars($datos['ubicacion']) ?>">
        </label>

        <label>Habilidades:
            <input type="text" name="habilidades" value="<?= htmlspecialchars($datos['habilidades']) ?>">
        </label>

        <label>Avatar:
            <input type="file" name="avatar" accept="image/*">
        </label>

        <?php if (!empty($datos['avatar'])): ?>
            <div class="avatar-preview">
                <strong>Avatar actual:</strong><br>
                <img src="avatars/<?= htmlspecialchars($datos['avatar']) ?>" alt="Avatar" width="100">
            </div>
        <?php endif; ?>

        <br><br>
        <button type="submit">Guardar cambios</button>
    </form>
    </div>
</body>
</html>
