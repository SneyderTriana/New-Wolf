<?php
// Se incluye el archivo que define rutas absolutas como HEADER o FOOTER
require_once __DIR__ . '/../config/addressDocument.php';
?>

<!-- Enlace al archivo de estilos -->
<link rel="stylesheet" href="/login_1/assets/styles/style.css">

<body>

 <!-- Contenedor principal del formulario -->
 <div class="contenedor-form">
  <!-- Título del formulario -->
  <h2>Recuperar Contraseña</h2>

  <!-- Formulario que envía el correo del usuario para recuperación -->
  <form action="../config/recovery.php" method="POST">

 <!-- Campo oculto para indicar el tipo de acción (más descriptivo para recovery.php) -->
 <input type="hidden" name="action" value="recover_password_request">

 <!-- Campo de entrada para el correo electrónico -->
 <div class="contenedor-input">
  <span class="icono">👤</span>
  <input type="email" name="email" id="email" required> <!-- Asegura name="email" y añade id para el label -->
  <label for="email">Correo</label> <!-- 'for' del label coincide con el 'id' del input -->
 </div>

 <br>

 <!-- Botón para enviar el formulario (texto más claro) -->
 <button type="submit" class="btn">Enviar Enlace de Recuperación</button>

 <!-- Enlace para redirigir al formulario de registro -->
 <div class="registrar">
  <p>¿No tienes cuenta? <a href="register.php">Registrarse</a></p>
 </div>
  </form>
 </div>

</body>

</html>