<link rel="stylesheet" href="../assets/styles/style.css">
<?php
// Incluye archivos de configuración y cabecera
require_once __DIR__ . '/../config/addressDocument.php';
require_once HEADER; // Asume que HEADER incluye 'session_start()' con la comprobación PHP_SESSION_NONE
include __DIR__ . '/../config/conexion_mysqli_oop.php'; // Incluye el archivo de conexión a DB

// Muestra todos los errores de PHP (solo para desarrollo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica la conexión a la base de datos
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Error crítico: La conexión a la base de datos no está disponible.");
}

// Asegúrate de que la sesión esté iniciada y que $_SESSION['id_use'] contenga el ID del usuario
// Si 'HEADER' ya maneja session_start(), esta línea es redundante aquí, pero no daña.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Para propósitos de depuración o desarrollo, si el usuario no está logueado, asigna un ID de prueba.
// ¡REMOVER en producción y redirigir al login si el usuario no está autenticado!
if (!isset($_SESSION['id_use'])) {
    $_SESSION['id_use'] = 1; // Asigna un ID de usuario de prueba si no hay sesión
}

// Define la ruta de avatares para JavaScript
$avatar_path = AVATAR;
?>

<script type="text/javascript" src="../js/likes.js"></script>
<script type="text/javascript">
    // Define la ruta base para avatares para ser usada en JavaScript
    const AVATAR_PATH = "<?php echo $avatar_path; ?>";

    $(document).ready(function () {
        // Manejador para el envío de comentarios al presionar Enter
        $(".enviar-btn").keypress(function (event) {
            // Verifica si la tecla presionada es Enter (código 13)
            if (event.which == 13) {
                event.preventDefault(); // Previene el envío del formulario por defecto

                // Obtiene el ID de la publicación desde el ID del elemento padre del input de comentario
                var getpID = $(this).parent().attr('id').replace('record-', '');
                var comentario = $("#comentario-" + getpID).val(); // Obtiene el contenido del comentario
                var publicacion = getpID; // El ID de la publicación

                // Valida que el comentario no esté vacío
                if (comentario.trim() === '') {
                    alert('Debes añadir un comentario.');
                    return false; // Detiene la ejecución si el comentario está vacío
                }

                $.ajax({
                    type: "POST",
                    url: "agregarcomentario.php", // Script PHP para agregar comentarios
                    data: {
                        comentario: comentario, // Contenido del comentario
                        publicacion: publicacion // ID de la publicación
                    },
                    dataType: "json", // Espera una respuesta JSON
                    success: function (response) {
                        if (response.status === "success") {
                            // Añade el nuevo comentario al contenedor
                            $('#nuevocomentario' + getpID).append(response.html);
                            $("#comentario-" + getpID).val(''); // Limpia el campo de comentario
                        } else {
                            alert("Error al agregar el comentario: " + response.message);
                            console.error("Error del servidor (Comentario):", response.message);
                        }
                    },
                    error: function (xhr) {
                        // Maneja errores de comunicación AJAX
                        console.error("Error AJAX (Comentario):", xhr.responseText);
                        alert("Error al agregar el comentario. Intenta nuevamente.");
                    }
                });

                return false; // Detiene el evento
            }
        });
    });
</script>

<?php
// Lógica para la paginación de publicaciones
$CantidadMostrar = 5;
$compag = (int) (!isset($_GET['pag'])) ? 1 : $_GET['pag'];

// Obtener el total de publicaciones
$stmt_total_reg = $mysqli->prepare("SELECT COUNT(*) AS total FROM publicaciones");
$stmt_total_reg->execute();
$result_total_reg = $stmt_total_reg->get_result();
$totalr = $result_total_reg->fetch_assoc()['total'];
$stmt_total_reg->close();

$TotalRegistro = ceil($totalr / $CantidadMostrar); // Calcular el número total de páginas
$IncrimentNum = (($compag + 1) <= $TotalRegistro) ? ($compag + 1) : 0; // Para el botón 'Siguiente'
$offset = ($compag - 1) * $CantidadMostrar; // Calcular el offset para la consulta SQL

// Obtener las publicaciones para la página actual
$stmt_publicaciones = $mysqli->prepare("SELECT id_pub, id_use, contenido, fecha, imagen, likes FROM publicaciones ORDER BY id_pub DESC LIMIT ?, ?");
$stmt_publicaciones->bind_param("ii", $offset, $CantidadMostrar);
$stmt_publicaciones->execute();
$consulta = $stmt_publicaciones->get_result();

// Mostrar mensaje si no hay publicaciones
if ($consulta->num_rows === 0) {
    echo "<p style='text-align: center; margin-top: 20px;'>No hay publicaciones disponibles.</p>";
}

// Bucle para mostrar cada publicación
while ($lista = $consulta->fetch_assoc()) {
    $userid = $lista['id_use'];
    // Obtener información del usuario que hizo la publicación
    $stmt_usuariob = $mysqli->prepare("SELECT id_use, username, avatar FROM usuarios WHERE id_use = ?");
    $stmt_usuariob->bind_param("i", $userid);
    $stmt_usuariob->execute();
    $use = $stmt_usuariob->get_result()->fetch_assoc();
    $stmt_usuariob->close();

    $fot_ruta = '';
    // Obtener la ruta de la imagen si la publicación tiene una
    if ($lista['imagen'] != 0) {
        $stmt_fotos = $mysqli->prepare("SELECT ruta FROM fotos WHERE publicacion = ?");
        $stmt_fotos->bind_param("i", $lista['id_pub']);
        $stmt_fotos->execute();
        $row_foto = $stmt_fotos->get_result()->fetch_assoc();
        if ($row_foto) {
            $fot_ruta = $row_foto['ruta'];
        }
        $stmt_fotos->close();
    }
?>
    <div class="box box-widget">
        <div class="box-header with-border">
            <div class="user-block">
                <img class="img-circle" src="<?php echo AVATAR . '/' . htmlspecialchars($use['avatar'] ?? ''); ?>" alt="User Image">
                <span class="description" onclick="location.href='perfil.php?id=<?php echo htmlspecialchars($use['id_use'] ?? ''); ?>';" style="cursor:pointer; color: #3C8DBC;">
                    <?php echo htmlspecialchars($use['username'] ?? ''); ?>
                </span>
                <span class="description"><?php echo htmlspecialchars($lista['fecha'] ?? ''); ?></span>
            </div>
        </div>
        <div class="box-body">
            <p><?php echo htmlspecialchars($lista['contenido'] ?? ''); ?></p>
            <?php if ($lista['imagen'] != 0 && !empty($fot_ruta)) { ?>
                <img src="publicaciones/<?php echo htmlspecialchars($fot_ruta); ?>" width="100%">
            <?php } ?>
            <?php
            // Obtener el número de comentarios para esta publicación
            $stmt_num_comen = $mysqli->prepare("SELECT COUNT(*) AS num_comen FROM comentarios WHERE publicacion = ?");
            $stmt_num_comen->bind_param("i", $lista['id_pub']);
            $stmt_num_comen->execute();
            $numcomen = $stmt_num_comen->get_result()->fetch_assoc()['num_comen'];
            $stmt_num_comen->close();
            ?>
            <ul class="list-inline">
                <li>
                    <a href="#" class="link-black text-sm like" id="<?php echo htmlspecialchars($lista['id_pub']); ?>">
                        <i class="fa fa-thumbs-o-up"></i>
                        <?php
                            // Muestra "No me gusta" si el usuario ya dio like, "Me gusta" si no
                            // Para hacer esto dinámico, necesitarías consultar si el usuario actual dio like.
                            // Por simplicidad, aquí mostramos "Me gusta" por defecto o basado en `likes` > 0.
                            // La lógica en `megusta.php` ya decide el texto correcto.
                            echo ($lista['likes'] > 0 ? "No me gusta" : "Me gusta");
                        ?>
                    </a>
                </li>
                <li>
                    <span class="pull-right text-muted" id="likes_<?php echo htmlspecialchars($lista['id_pub']); ?>">
                        (<?php echo htmlspecialchars($lista['likes'] ?? 0); ?>)
                    </span>
                </li>
                <li>
                    <span class="text-muted"><i class="fa fa-comments-o"></i> Comentarios
                        (<?php echo htmlspecialchars($numcomen); ?>)</span>
                </li>
            </ul>
        </div>
        <div class="box-footer box-comments">
            <?php
            // Obtener los últimos 2 comentarios
            $stmt_comentarios = $mysqli->prepare("SELECT id_com, usuario, comentario, fecha FROM comentarios WHERE publicacion = ? ORDER BY id_com DESC LIMIT 2");
            $stmt_comentarios->bind_param("i", $lista['id_pub']);
            $stmt_comentarios->execute();
            $result_comentarios = $stmt_comentarios->get_result();
            while ($com = $result_comentarios->fetch_assoc()) {
                // Obtener información del usuario que hizo el comentario
                $stmt_usuarioc = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
                $stmt_usuarioc->bind_param("i", $com['usuario']);
                $stmt_usuarioc->execute();
                $usec = $stmt_usuarioc->get_result()->fetch_assoc();
                $stmt_usuarioc->close();
            ?>
                <div class="box-comment">
                    <img class="img-circle img-sm" src="<?php echo AVATAR . '/' . htmlspecialchars($usec['avatar'] ?? ''); ?>" alt="Avatar">
                    <div class="comment-text">
                        <span class="username">
                            <?php echo htmlspecialchars($usec['username'] ?? ''); ?>
                            <span class="text-muted pull-right"><?php echo htmlspecialchars($com['fecha'] ?? ''); ?></span>
                        </span>
                        <?php echo htmlspecialchars($com['comentario'] ?? ''); ?>
                    </div>
                </div>
            <?php }
            $stmt_comentarios->close(); ?>
            <?php if ($numcomen > 2) { ?>
                <br>
                <center><span onclick="location.href='publicacion.php?id=<?php echo htmlspecialchars($lista['id_pub']); ?>';" style="cursor:pointer; color: #3C8DBC;">Ver todos los comentarios</span></center>
            <?php } ?>
            <div id="nuevocomentario<?php echo htmlspecialchars($lista['id_pub']); ?>"></div>
            <br>
            <form method="post" action="">
                <label id="record-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="text" class="enviar-btn form-control input-sm" style="width: 550px;" placeholder="Escribe un comentario" name="comentario" id="comentario-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                </label>
            </form>
        </div>
    </div><br><br>
<?php }
$stmt_publicaciones->close();
// Enlace para la siguiente página de publicaciones
if ($IncrimentNum > 0) {
    echo "<a href=\"publicaciones.php?pag=$IncrimentNum\">Siguiente</a>";
}
?>