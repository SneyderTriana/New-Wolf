<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Confirmar Pago</title>

  <!-- Librería de SweetAlert2 para ventanas emergentes -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <!-- jQuery para usar AJAX -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- Estilos (opcional: puedes agregar tu CSS aquí si deseas) -->
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f6f9;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
  </style>
</head>
<body onload="Pago()">

<script>
  // Función para confirmar el pago
  function Pago() {
    Swal.fire({
      title: 'Confirmar Pago',
      text: "¿Estás seguro de que deseas realizar este pago?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, pagar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        // Enviar solicitud AJAX para vaciar el carrito
        $.ajax({
          url: '../controller/auxiliar/borrarcarro.php',
          type: 'POST',
          dataType: 'json',
          success: function (response) {
            if (response.status === 'OK') {
              Swal.fire(
                '¡Pago Realizado!',
                'Tu compra ha sido procesada exitosamente.',
                'success'
              ).then(() => {
                window.location.href = "tienda.php"; // Redirige a la tienda
              });
            } else {
              Swal.fire('Error', response.message || 'Error al procesar el pago.', 'error');
            }
          },
          error: function () {
            Swal.fire('Error', 'Problema de comunicación al procesar el pago.', 'error');
          }
        });
      } else {
        // Si se cancela, redirige o muestra un mensaje
        Swal.fire('Cancelado', 'No se realizó el pago.', 'info').then(() => {
          window.location.href = "tienda.php";
        });
      }
    });
  }
</script>

</body>
</html>
