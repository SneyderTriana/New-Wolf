<?php
// C:\xampp\htdocs\login_1\view\establecer_nueva_clave.php

// Incluye archivos de configuración y cabecera si es necesario para el diseño
require_once __DIR__ . '/../config/addressDocument.php';
// require_once HEADER; // Descomenta si necesitas el header completo aquí

// Mostrar errores para depuración (SOLO EN DESARROLLO)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$email_recuperacion = '';
$token_recuperacion = '';
$mensaje_estado = ''; // Para mensajes de éxito o error

// 1. Validar la presencia de email y token en la URL
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email_recuperacion = htmlspecialchars($_GET['email']);
    $token_recuperacion = htmlspecialchars($_GET['token']);

    // --- LÓGICA REAL DE VALIDACIÓN DE TOKEN (PARA PRODUCCIÓN) ---
    // Aquí deberías conectar a la DB y verificar:
    // 1. Que el token exista para este email.
    // 2. Que el token no haya expirado.
    // 3. Que el token no haya sido usado ya.
    // Si la validación falla, establece $mensaje_estado con un error.
    // require_once __DIR__ . '/../config/conexion_mysqli_oop.php';
    // $stmt_validate_token = $conexion->prepare("SELECT id FROM password_resets WHERE email = ? AND token = ? AND expires_at > NOW()");
    // $stmt_validate_token->bind_param("ss", $email_recuperacion, $token_recuperacion);
    // $stmt_validate_token->execute();
    // $result_validate_token = $stmt_validate_token->get_result();
    // if ($result_validate_token->num_rows === 0) {
    //     $mensaje_estado = "El enlace de recuperación es inválido o ha expirado. Por favor, solicita uno nuevo.";
    // }
    // $stmt_validate_token->close();
    // --- FIN LÓGICA REAL ---

    // ✅ SIMULACIÓN PARA PRUEBAS: Si los parámetros están presentes, asumimos que son válidos.
    if (empty($email_recuperacion) || empty($token_recuperacion)) {
        $mensaje_estado = "Enlace de recuperación inválido o incompleto.";
    }

} else {
    $mensaje_estado = "Acceso denegado. Por favor, usa el enlace de recuperación enviado a tu correo.";
}

// 2. Procesar el formulario de cambio de contraseña (cuando se envía desde esta página)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['new_password']) && isset($_POST['confirm_new_password']) && isset($_POST['email'])) {
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];
    $email_form = $_POST['email']; // El email oculto enviado desde el formulario

    if ($new_password !== $confirm_new_password) {
        $mensaje_estado = "Las contraseñas no coinciden.";
    } elseif (strlen($new_password) < 6) { // Ejemplo de validación mínima
        $mensaje_estado = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        // ✅ Todo bien, redirigir a change_password.php con los datos
        // change_password.php espera 'email' y 'new_password' en POST
        ?>
        <form id="redirectForm" action="../config/change_password.php" method="POST">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email_form); ?>">
            <input type="hidden" name="new_password" value="<?php echo htmlspecialchars($new_password); ?>">
        </form>
        <script type="text/javascript">
            document.getElementById('redirectForm').submit(); // Envía el formulario automáticamente
        </script>
        <?php
        exit(); // Detiene la ejecución para asegurar la redirección
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Establecer Nueva Contraseña</title>
    <link rel="stylesheet" href="../assets/styles/style.css"> <!-- Asegúrate de que esta ruta sea correcta -->
    <style>
        /* Estilos específicos para este formulario, si no están en style.css */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url("/login_1/assets/imagenes/IMAGEN.jpeg") no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            overflow: hidden;
        }
        .contenedor-form {
            width: 400px;
            padding: 40px;
            background-color: rgba(0, 0, 0, 0.7);
            border: 2px solid rgba(255, 255, 255, 0.5);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.8);
            text-align: center;
        }
        .contenedor-form h2 {
            font-size: 2em;
            color: var(--text-white);
            margin-bottom: 30px;
        }
        .contenedor-input {
            position: relative;
            width: 100%;
            height: 50px;
            margin: 30px 0;
            border-bottom: 2px solid #bbb;
        }
        .contenedor-input input {
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            font-size: 1em;
            color: var(--text-white);
            padding: 0 35px 0 5px;
        }
        .contenedor-input label {
            position: absolute;
            top: 50%;
            left: 5px;
            transform: translateY(-50%);
            color: var(--text-white);
            font-size: 1em;
            font-weight: 500;
            pointer-events: none;
            transition: 0.5s;
        }
        .contenedor-input input:focus ~ label,
        .contenedor-input input:valid ~ label {
            top: -5px;
            font-size: 0.8em;
        }
        .btn-submit {
            width: 100%;
            height: 45px;
            background-color: var(--purple-main);
            border: none;
            outline: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            color: var(--text-white);
            font-weight: 600;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }
        .btn-submit:hover {
            background-color: var(--purple-dark);
        }
        .mensaje-error {
            color: #ff4d4d;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .mensaje-exito {
            color: #4CAF50;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="contenedor-form">
        <h2>Establecer Nueva Contraseña</h2>

        <?php if (!empty($mensaje_estado)): ?>
            <p class="<?php echo (strpos($mensaje_estado, 'inválido') !== false || strpos($mensaje_estado, 'denegado') !== false || strpos($mensaje_estado, 'coinciden') !== false || strpos($mensaje_estado, 'caracteres') !== false) ? 'mensaje-error' : 'mensaje-exito'; ?>">
                <?php echo $mensaje_estado; ?>
            </p>
        <?php endif; ?>

        <?php if (empty($mensaje_estado) || strpos($mensaje_estado, 'coinciden') !== false || strpos($mensaje_estado, 'caracteres') !== false): ?>
            <form action="" method="POST"> <!-- El action vacío envía a sí mismo -->
                <!-- Campo oculto para enviar el email al script de cambio de contraseña -->
                <!-- Se añade id y autocomplete para mejorar la accesibilidad y UX -->
                <input type="hidden" name="email" id="email_hidden" value="<?php echo htmlspecialchars($email_recuperacion); ?>" autocomplete="email">

                <div class="contenedor-input">
                    <!-- Se añade id y autocomplete="new-password" -->
                    <input type="password" name="new_password" id="new_password" required autocomplete="new-password">
                    <label for="new_password">Nueva Contraseña</label>
                </div>
                <div class="contenedor-input">
                    <!-- Se añade id y autocomplete="new-password" -->
                    <input type="password" name="confirm_new_password" id="confirm_new_password" required autocomplete="new-password">
                    <label for="confirm_new_password">Confirmar Contraseña</label>
                </div>
                <br>
                <button type="submit" class="btn-submit">Cambiar Contraseña</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
