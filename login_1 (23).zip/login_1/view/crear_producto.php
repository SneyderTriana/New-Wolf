<?php
require_once __DIR__ . '/../config/addressDocument.php';
include __DIR__ . '/../config/conexion_mysqli_proc.php';
require_once HEADER;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = $_POST['nombre'];
  $precio = $_POST['precio'];
  $descripcion = $_POST['descripcion'];

  if (!empty($_FILES['img']['name'])) {
    $imgNombre = basename($_FILES['img']['name']);
    $rutaDestino = __DIR__ . "/productos/img/" . $imgNombre;

    if (move_uploaded_file($_FILES['img']['tmp_name'], $rutaDestino)) {
      $insert = $conexion->prepare("INSERT INTO articulos (nombre, precio, descripcion, img) VALUES (?, ?, ?, ?)");
      $insert->bind_param("sdss", $nombre, $precio, $descripcion, $imgNombre);

      if ($insert->execute()) {
        echo "<script>alert('Producto agregado correctamente'); window.location.href='tienda.php';</script>";
        exit;
      } else {
        echo "<script>alert('Error al guardar en la base de datos');</script>";
      }

      $insert->close();
    } else {
      echo "<script>alert('Error al subir la imagen');</script>";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Crear producto</title>
  <link rel="stylesheet" href="/login_1/assets/styles/style.css">
</head>
<body>
<div class="container my-4">
  <h3>Crear nuevo producto</h3>
  <form method="POST" enctype="multipart/form-data" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Nombre</label>
      <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Precio</label>
      <input type="number" step="0.01" name="precio" class="form-control" required>
    </div>
    <div class="col-12">
      <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="4" required></textarea>
    </div>
    <div class="col-12">
      <label class="form-label">Imagen del producto</label>
      <input type="file" name="img" class="form-control" accept="image/*" required>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Guardar producto</button>
      <a href="tienda.php" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>
</div>
</body>
</html>
