<?php
// Incluye archivos de configuración y conexión a la base de datos.
// Esto asume que este script se llama desde una ruta donde ../config/ es accesible.
include __DIR__ . '/../config/conexion_mysqli_oop.php'; // Asegúrate que esta ruta es correcta y el archivo existe

// Iniciar sesión solo si no está activa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Para depuración, mostrar todos los errores. REMOVER EN PRODUCCIÓN.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Validar conexión a la base de datos
if (!isset($mysqli) || $mysqli->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["status" => "error", "message" => "Error crítico: La conexión a la base de datos no está disponible."]);
    exit;
}

// **CORRECCIÓN 1: Consistencia en el nombre de la variable de sesión para el ID de usuario**
// Si el ID de usuario en la DB es `id_use`, entonces la sesión debería usar `id_use`.
// Asegúrate de que, en tu script de login, guardas $_SESSION['id_use'] = $id_del_usuario;
if (!isset($_SESSION['id_use'])) {
    // Esto es solo para PRUEBAS para que el script no falle si no hay sesión real.
    // REMOVER O MANEJAR LA REDIRECCIÓN A LOGIN EN PRODUCCIÓN.
    $_SESSION['id_use'] = 1; // Asigna un ID de usuario existente para pruebas
    // En producción, si no hay sesión, deberías:
    // http_response_code(401);
    // echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
    // exit;
}

// **CORRECCIÓN 2: Obtener el ID de la publicación correctamente desde POST**
$id_usuario_sesion = intval($_SESSION['id_use']); // El ID del usuario que da like
$id_publicacion_post = isset($_POST['id_pub']) ? intval($_POST['id_pub']) : null; // El ID de la publicación a la que se da like

// Validar que tenemos ambos IDs necesarios
if ($id_usuario_sesion === 0 || $id_publicacion_post === null) { // id_usuario_sesion === 0 si intval falla
    http_response_code(400); // Bad Request
    echo json_encode(["status" => "error", "message" => "Datos incompletos: ID de usuario o publicación."]);
    exit;
}

// Verificar si el usuario ya dio "me gusta" a esta publicación
// La tabla `likes` tiene columnas `usuario` y `post` (image_028e39.png)
$sql_check = "SELECT 1 FROM likes WHERE post = ? AND usuario = ?";
$stmt = $mysqli->prepare($sql_check);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error al preparar verificación de like: " . $mysqli->error]);
    exit;
}
$stmt->bind_param("ii", $id_publicacion_post, $id_usuario_sesion); // post, usuario
$stmt->execute();
$stmt->store_result();
$has_liked = $stmt->num_rows > 0; // true si ya dio like, false si no
$stmt->close();

if (!$has_liked) {
    // Insertar like
    $sql_insert = "INSERT INTO likes (usuario, post, fecha) VALUES (?, ?, NOW())";
    $stmt_insert = $mysqli->prepare($sql_insert);
    if (!$stmt_insert) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al preparar inserción de like: " . $mysqli->error]);
        exit;
    }
    $stmt_insert->bind_param("ii", $id_usuario_sesion, $id_publicacion_post); // usuario, post
    if (!$stmt_insert->execute()) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al ejecutar inserción de like: " . $stmt_insert->error]);
        exit;
    }
    $stmt_insert->close();

    // Incrementar contador de likes en la publicación
    $sql_update = "UPDATE publicaciones SET likes = likes + 1 WHERE id_pub = ?";
    $stmt_update = $mysqli->prepare($sql_update);
    if (!$stmt_update) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al preparar incremento de likes: " . $mysqli->error]);
        exit;
    }
    $stmt_update->bind_param("i", $id_publicacion_post);
    if (!$stmt_update->execute()) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al ejecutar incremento de likes: " . $stmt_update->error]);
        exit;
    }
    $stmt_update->close();

    $estado_texto_btn = "No me gusta"; // Texto para el botón después de dar like
} else {
    // Eliminar like
    $sql_delete = "DELETE FROM likes WHERE post = ? AND usuario = ?";
    $stmt_delete = $mysqli->prepare($sql_delete);
    if (!$stmt_delete) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al preparar eliminación de like: " . $mysqli->error]);
        exit;
    }
    $stmt_delete->bind_param("ii", $id_publicacion_post, $id_usuario_sesion); // post, usuario
    if (!$stmt_delete->execute()) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al ejecutar eliminación de like: " . $stmt_delete->error]);
        exit;
    }
    $stmt_delete->close();

    // Decrementar contador de likes en la publicación
    $sql_update = "UPDATE publicaciones SET likes = likes - 1 WHERE id_pub = ?";
    $stmt_update = $mysqli->prepare($sql_update);
    if (!$stmt_update) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al preparar decremento de likes: " . $mysqli->error]);
        exit;
    }
    $stmt_update->bind_param("i", $id_publicacion_post);
    if (!$stmt_update->execute()) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al ejecutar decremento de likes: " . $stmt_update->error]);
        exit;
    }
    $stmt_update->close();

    $estado_texto_btn = "Me gusta"; // Texto para el botón después de quitar like
}

// Obtener cantidad actualizada de likes de la publicación
$sql_likes = "SELECT likes FROM publicaciones WHERE id_pub = ?";
$stmt_likes = $mysqli->prepare($sql_likes);
if (!$stmt_likes) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error al preparar obtención de likes: " . $mysqli->error]);
    exit;
}
$stmt_likes->bind_param("i", $id_publicacion_post);
$stmt_likes->execute();
$result_likes = $stmt_likes->get_result();
$row = $result_likes->fetch_assoc();
$current_likes_count = $row['likes'] ?? 0; // Usa 0 si no se encuentra la publicación
$stmt_likes->close();

// Formar respuesta JSON para el cliente
$icon = "<i class='fa fa-thumbs-o-up'></i> ";
$likes_text = " (" . $current_likes_count . ")"; // Formato (cantidad)
$button_text = $icon . $estado_texto_btn; // Texto del botón (ej. "Me gusta" o "No me gusta")

echo json_encode([
    'status' => 'success', // Agregamos un status para que el JS lo maneje bien
    'likes_count' => $current_likes_count, // Cantidad numérica de likes
    'button_html' => $button_text, // HTML del botón
    'message' => 'Operación de like exitosa.'
]);
exit;