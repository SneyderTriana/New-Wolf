<?php
// C:\xampp\htdocs\login_1\config\change_password.php

// Mostrar todos los errores de PHP para depuración (SOLO EN DESARROLLO)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Incluir la conexión a la base de datos
require_once('conexion_mysqli_oop.php'); // Asegúrate de que esta ruta sea correcta y que $conexion se define aquí

// 1. Verificar que los datos necesarios han sido enviados por POST
if (isset($_POST['email']) && isset($_POST['new_password'])) {
    // 2. Obtener y sanear los datos
    $email = trim($_POST['email']);
    $new_password = $_POST['new_password'];

    // --- INICIO DE LOGS DE DEPURACIÓN DETALLADOS ---
    error_log("DEBUG_CHANGE_PASSWORD: Script change_password.php iniciado.");
    error_log("DEBUG_CHANGE_PASSWORD: Recibido Email = '" . $email . "'");
    error_log("DEBUG_CHANGE_PASSWORD: Recibida new_password (sin hashear) = '" . $new_password . "'");

    // Verificar si la conexión a la DB está disponible
    if (!isset($conexion) || $conexion->connect_error) {
        error_log("DEBUG_CHANGE_PASSWORD: ERROR CRÍTICO - La variable \$conexion no está definida o la conexión falló: " . ($conexion->connect_error ?? 'Variable no definida'));
        header("Location: ../view/recuperarClave.php?message=db_connection_error");
        exit();
    }
    // --- FIN DE LOGS DE DEPURACIÓN DETALLADOS ---

    // 3. Hashear la nueva contraseña
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    error_log("DEBUG_CHANGE_PASSWORD: Contraseña hasheada = '" . $hashed_password . "'");

    // === PASO DE DEPURACIÓN CRÍTICO: VERIFICAR SI EL USUARIO EXISTE ANTES DEL UPDATE ===
    $stmt_check_user = $conexion->prepare("SELECT id_use FROM usuarios WHERE correo = ?");
    if ($stmt_check_user === false) {
        error_log("DEBUG_CHANGE_PASSWORD: ERROR - Fallo al preparar la consulta de verificación de usuario: " . $conexion->error);
        header("Location: ../view/recuperarClave.php?message=prepare_check_failed");
        exit();
    }
    $stmt_check_user->bind_param("s", $email);
    $stmt_check_user->execute();
    $result_check_user = $stmt_check_user->get_result();

    if ($result_check_user->num_rows === 0) {
        // Si no se encontró ningún usuario con ese email, ¡este es el problema!
        error_log("DEBUG_CHANGE_PASSWORD: ERROR - El email '" . $email . "' NO fue encontrado en la tabla 'usuarios'.");
        header("Location: ../view/recuperarClave.php?message=email_not_found_in_db");
        $stmt_check_user->close();
        exit();
    } else {
        error_log("DEBUG_CHANGE_PASSWORD: El email '" . $email . "' FUE encontrado en la tabla 'usuarios'. Procediendo con la actualización.");
    }
    $stmt_check_user->close();
    // ===================================================================================

    // 4. Preparar la consulta SQL para actualizar la contraseña
    $stmt = $conexion->prepare("UPDATE usuarios SET password = ? WHERE correo = ?");

    if ($stmt === false) {
        error_log("DEBUG_CHANGE_PASSWORD: ERROR - Fallo al preparar la consulta SQL de actualización: " . $conexion->error);
        header("Location: ../view/recuperarClave.php?message=prepare_failed");
        exit();
    } else {
        error_log("DEBUG_CHANGE_PASSWORD: Consulta de actualización preparada con éxito.");
    }

    // 5. Vincular los parámetros y ejecutar
    $stmt->bind_param("ss", $hashed_password, $email);
    error_log("DEBUG_CHANGE_PASSWORD: Parámetros vinculados para UPDATE: hashed_password='" . $hashed_password . "', email='" . $email . "'");

    if ($stmt->execute()) {
        error_log("DEBUG_CHANGE_PASSWORD: Consulta de actualización ejecutada con éxito.");
        error_log("DEBUG_CHANGE_PASSWORD: Filas afectadas por UPDATE: " . $stmt->affected_rows);

        if ($stmt->affected_rows === 0) {
            // Esto solo debería ocurrir si la contraseña hasheada es idéntica a la anterior (muy raro con password_hash)
            // o si hubo un problema de concurrencia, pero el log anterior de "email encontrado" ya lo descartaría.
            error_log("DEBUG_CHANGE_PASSWORD: WARNING - UPDATE afectó 0 filas. Posiblemente la nueva contraseña es la misma.");
            header("Location: ../view/recuperarClave.php?message=password_same_or_no_change");
            $stmt->close();
            exit();
        }

        error_log("DEBUG_CHANGE_PASSWORD: Contraseña actualizada exitosamente para el email: " . $email);
        header("Location: /login_1/view/login.php?message=success_password");
        $stmt->close();
        exit();
    } else {
        error_log("DEBUG_CHANGE_PASSWORD: ERROR - Fallo al ejecutar UPDATE: " . $stmt->error);
        header("Location: ../view/recuperarClave.php?message=db_update_error");
        $stmt->close();
        exit();
    }
} else {
    error_log("DEBUG_CHANGE_PASSWORD: Datos POST faltantes (email o new_password). Esto indica un problema con el formulario HTML o la URL de acceso.");
    header("Location: ../view/recuperarClave.php?message=missing_data");
    exit();
}
?>
