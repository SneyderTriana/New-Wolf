// Asegúrate de que jQuery esté cargado antes de este script.
$(document).ready(function() {
    // Escucha el evento 'click' en cualquier elemento con la clase 'like'.
    $(".like").click(function() {
        // Obtiene el ID del elemento clickeado. Este ID debe ser el ID de la publicación.
        var publicacionId = this.id; // Asume que el ID del elemento es el ID de la publicación.

        // Valida que el ID de la publicación sea válido antes de enviar la solicitud.
        if (!publicacionId || publicacionId === "") {
            console.error("Error JS: ID de publicación no encontrado.");
            return; // Detiene la ejecución si el ID es inválido.
        }

        $.ajax({
            url: 'megusta.php', // Ruta al script PHP que maneja los likes.
            type: 'POST', // Usa el método POST para enviar datos.
            data: { id_pub: publicacionId }, // Envía el ID de la publicación con la clave 'id_pub'.
            dataType: 'json', // Espera una respuesta en formato JSON.
            success: function(response) {
                // Se ejecuta si la solicitud AJAX es exitosa (código HTTP 200 OK).
                if (response.status === 'success') {
                    // Actualiza el texto del contador de likes usando el ID de la publicación.
                    $("#likes_" + publicacionId).text("(" + response.likes_count + ")");
                    // Actualiza el HTML interno del botón/enlace de like.
                    $("#" + publicacionId).html(response.button_html);
                } else {
                    // Maneja errores reportados por el servidor PHP.
                    console.error("Error del servidor:", response.message);
                }
            },
            error: function(xhr, status, error) {
                // Se ejecuta si hay un error en la comunicación AJAX.
                console.error("Error AJAX:", status, error, xhr.responseText);
            }
        });
    });
});