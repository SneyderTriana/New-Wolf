<?php
// ✅ Asegura que la sesión esté iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ✅ Define el tipo de contenido como JSON
header('Content-Type: application/json');

// ✅ Inicializa contador
$cantidad_final = 0;

// ✅ Suma todas las cantidades si existe el carrito
if (!empty($_SESSION['carrito'])) {
    foreach ($_SESSION['carrito'] as $item) {
        $cantidad_final += intval($item['cantidad'] ?? 0);
    }
}

// ✅ Retorna respuesta JSON
echo json_encode([
    'status' => 'OK',
    'count' => $cantidad_final
]);
exit;
?>
