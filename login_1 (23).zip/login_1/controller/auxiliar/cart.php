<?php
// ✅ Evita errores por envío de encabezados después de output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// ✅ Inicializa el carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

$response = ['status' => 'KO', 'message' => 'Petición inválida.'];

// ✅ Añadir producto al carrito
if (isset($_POST['titulo'], $_POST['precio'], $_POST['cantidad'], $_POST['ref'])) {
    $titulo = $_POST['titulo'];
    $precio = floatval($_POST['precio']);
    $cantidad = intval($_POST['cantidad']);
    $ref = $_POST['ref'];

    $encontrado = false;

    foreach ($_SESSION['carrito'] as $key => $item) {
        if (isset($item['ref']) && $item['ref'] === $ref) {
            $_SESSION['carrito'][$key]['cantidad'] += $cantidad;
            $encontrado = true;
            break;
        }
    }

    if (!$encontrado) {
        $_SESSION['carrito'][] = [
            "titulo" => $titulo,
            "precio" => $precio,
            "cantidad" => $cantidad,
            "ref" => $ref
        ];
    }

    $response = ['status' => 'OK', 'message' => 'Producto añadido al carrito.'];
}

// ✅ Actualizar cantidad de un producto
elseif (isset($_POST['id_item_carrito'], $_POST['nueva_cantidad'])) {
    $id = intval($_POST['id_item_carrito']);
    $nueva_cantidad = intval($_POST['nueva_cantidad']);

    if (isset($_SESSION['carrito'][$id])) {
        if ($nueva_cantidad < 1) {
            unset($_SESSION['carrito'][$id]);
            $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Reindexar
            $response = ['status' => 'OK', 'message' => 'Producto eliminado del carrito.'];
        } else {
            $_SESSION['carrito'][$id]['cantidad'] = $nueva_cantidad;
            $response = ['status' => 'OK', 'message' => 'Cantidad actualizada.'];
        }
    } else {
        $response = ['status' => 'KO', 'message' => 'Artículo no encontrado en el carrito para actualizar.'];
    }
}

// ✅ Eliminar un producto por su índice
elseif (isset($_POST['id_eliminar_item'])) {
    $id_eliminar = intval($_POST['id_eliminar_item']);
    if (isset($_SESSION['carrito'][$id_eliminar])) {
        unset($_SESSION['carrito'][$id_eliminar]);
        $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Reindexar
        $response = ['status' => 'OK', 'message' => 'Producto eliminado del carrito.'];
    } else {
        $response = ['status' => 'KO', 'message' => 'Producto no encontrado para eliminar.'];
    }
}

// ✅ Enviar respuesta
echo json_encode($response);
