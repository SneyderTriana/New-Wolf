<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$carrito_mio = $_SESSION['carrito'] ?? [];
$total_carrito = 0;

if (!empty($carrito_mio)) {
    echo '<ul class="carrito-lista">';
    foreach ($carrito_mio as $index => $producto) {
        $titulo = htmlspecialchars($producto['titulo'] ?? 'Artículo Desconocido');
        $precio = floatval($producto['precio'] ?? 0);
        $cantidad = intval($producto['cantidad'] ?? 0);
        $ref = htmlspecialchars($producto['ref'] ?? '');

        $subtotal = $precio * $cantidad;
        $total_carrito += $subtotal;
        ?>
        <li class="carrito-item">
            <div class="fila-carrito">
                <div class="detalle-producto">
                    <h6><?php echo $titulo; ?></h6>
                    <small>Cantidad:
                        <input type="number" min="1" value="<?php echo $cantidad; ?>"
                               onchange="actualizar_cantidad_carrito(<?php echo $index; ?>, this.value)">
                    </small>
                </div>
                <div class="precio-eliminar">
                    <span><?php echo number_format($subtotal, 2); ?>€</span>
                    <button class="eliminar-btn"
                            onclick="eliminar_item_carrito(<?php echo $index; ?>)">X</button>
                </div>
            </div>
        </li>
        <?php
    }
    echo '</ul>';

    echo '<div class="carrito-total">';
    echo '<span>Total (EUR)</span>';
    echo '<strong>' . number_format($total_carrito, 2) . '€</strong>';
    echo '</div>';
} else {
    echo '<p class="carrito-vacio">Tu carrito está vacío.</p>';
}
?>

<script>
function actualizar_cantidad_carrito(id, nueva_cantidad) {
    if (nueva_cantidad < 1) {
        nueva_cantidad = 1;
    }
    $.ajax({
        url: 'auxiliar/cart.php',
        type: 'POST',
        dataType: 'json',
        data: { id_item_carrito: id, nueva_cantidad: nueva_cantidad },
        success: function (response) {
            if (response.status === 'OK') {
                consultar_carrito();
                count_carrito();
            } else {
                Swal.fire('Error', response.message || 'Error al actualizar cantidad', 'error');
            }
        },
        error: function () {
            Swal.fire('Error', 'Problema al comunicarse con el servidor', 'error');
        }
    });
}

function eliminar_item_carrito(id_eliminar) {
    Swal.fire({
        title: '¿Eliminar este producto?',
        text: "Esta acción no se puede deshacer.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'auxiliar/cart.php',
                type: 'POST',
                dataType: 'json',
                data: { id_eliminar_item: id_eliminar },
                success: function (response) {
                    if (response.status === 'OK') {
                        Swal.fire('¡Eliminado!', 'Producto eliminado del carrito.', 'success');
                        consultar_carrito();
                        count_carrito();
                    } else {
                        Swal.fire('Error', response.message || 'Error al eliminar producto', 'error');
                    }
                },
                error: function () {
                    Swal.fire('Error', 'Problema al comunicarse con el servidor', 'error');
                }
            });
        }
    });
}
</script>
