<?php
 if (session_status() === PHP_SESSION_NONE) {
    session_start(); // ✅ Solo se ejecuta si aún no hay una sesión activa
}

header('Content-Type: application/json');

unset($_SESSION['carrito']); // Elimina la variable de sesión 'carrito'

echo json_encode(['status' => 'OK', 'message' => 'Carrito vaciado correctamente.']);
exit;
?>