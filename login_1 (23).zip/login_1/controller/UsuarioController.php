<?php
// C:\xampp\htdocs\login_1\controller\UsuarioController.php

require_once __DIR__ . '/../model/usuario.php';

class UsuarioController
{
    private $usuarioModel;

    public function __construct()
    {
        $this->usuarioModel = new Usuario();
        error_log("DEBUG_USUARIO_CONTROLLER: Instancia de UsuarioModel creada.");
    }

    public function login($username, $password)
    {
        return $this->usuarioModel->login($username, $password);
    }

    public function registrar($username, $password, $nombre, $correo, $genero, $fechaNacimiento)
    {
        return $this->usuarioModel->registrar($username, $password, $nombre, $correo, $genero, $fechaNacimiento);
    }

    public function obtenerDatosUsuario()
    {
        if (!isset($_SESSION['id'])) {
            error_log("DEBUG_USUARIO_CONTROLLER: No hay sesión activa para obtener datos de usuario.");
            return null;
        }

        return $this->usuarioModel->obtenerUsuarioPorId($_SESSION['id']);
    }

    public function actualizarPerfil()
    {
        error_log("DEBUG_USUARIO_CONTROLLER: Método actualizarPerfil() iniciado.");

        if (!isset($_SESSION['id'])) {
            error_log("DEBUG_USUARIO_CONTROLLER: ERROR - Sesión no iniciada.");
            return false;
        }

        $id_usuario = $_SESSION['id'];

        // ✅ Recolección segura y saneada
        $nombre         = trim($_POST['nombre'] ?? '');
        $username       = trim($_POST['username'] ?? '');
        $correo         = trim($_POST['correo'] ?? '');
        $genero         = trim($_POST['genero'] ?? '');
        $fechaNacimiento= trim($_POST['fechaNacimiento'] ?? '');
        $acercaDeMi     = trim($_POST['acercaDeMi'] ?? '');
        $educacion      = trim($_POST['educacion'] ?? '');
        $ubicacion      = trim($_POST['ubicacion'] ?? '');
        $habilidades    = trim($_POST['habilidades'] ?? '');

        // ✅ Validación mínima (puedes extender con regex si deseas)
        if (empty($nombre) || empty($username) || empty($correo)) {
            error_log("DEBUG_USUARIO_CONTROLLER: ERROR - Campos requeridos vacíos.");
            return false;
        }

        // ✅ Manejo del avatar
        $avatar = null;
        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $nombre_archivo = basename($_FILES['avatar']['name']);
            $extension = strtolower(pathinfo($nombre_archivo, PATHINFO_EXTENSION));
            $ext_permitidas = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array($extension, $ext_permitidas)) {
                $target_dir = __DIR__ . '/../view/avatars/';
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                $avatar = uniqid('avatar_') . "." . $extension; // nombre único
                $ruta_archivo = $target_dir . $avatar;

                if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $ruta_archivo)) {
                    error_log("DEBUG_USUARIO_CONTROLLER: ERROR - Fallo al mover el archivo.");
                    $avatar = null;
                } else {
                    error_log("DEBUG_USUARIO_CONTROLLER: Avatar cargado exitosamente.");
                }
            } else {
                error_log("DEBUG_USUARIO_CONTROLLER: Formato de imagen no permitido.");
            }
        }

        // ✅ Si no hay avatar nuevo, usamos el existente
        if (!$avatar) {
            $datos_actuales = $this->usuarioModel->obtenerUsuarioPorId($id_usuario);
            $avatar = $datos_actuales['avatar'] ?? null;
        }

        // ✅ Actualizar usuario en modelo
        $success = $this->usuarioModel->actualizarUsuario(
            $id_usuario,
            $nombre,
            $username,
            $correo,
            $genero,
            $fechaNacimiento,
            $avatar,
            $acercaDeMi,
            $educacion,
            $ubicacion,
            $habilidades
        );

        if ($success) {
            error_log("DEBUG_USUARIO_CONTROLLER: Perfil actualizado correctamente.");

            // ✅ Actualiza sesión (si aplica en tu sistema)
            $_SESSION['user']['nombre'] = $nombre;
            $_SESSION['user']['username'] = $username;
            $_SESSION['user']['correo'] = $correo;
            $_SESSION['user']['genero'] = $genero;
            $_SESSION['user']['fechaNacimiento'] = $fechaNacimiento;
            $_SESSION['user']['avatar'] = $avatar;
            $_SESSION['user']['acercaDeMi'] = $acercaDeMi;
            $_SESSION['user']['educacion'] = $educacion;
            $_SESSION['user']['ubicacion'] = $ubicacion;
            $_SESSION['user']['habilidades'] = $habilidades;
        } else {
            error_log("DEBUG_USUARIO_CONTROLLER: ERROR - No se pudo actualizar el perfil.");
        }

        return $success;
    }
}
?>
