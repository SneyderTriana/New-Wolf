// js/script.js

// Añadir un artículo al carrito
function envia_carrito(ref, titulo, precio, cantidad) {
  var parametros = { ref, titulo, precio, cantidad };

  $.ajax({
    data: parametros,
    url: "/login_1/controller/auxiliar/cart.php",
    type: "POST",
    dataType: "json",
    success: function (response) {
      if (response.status !== "OK") {
        Swal.fire(
          "Error!",
          response.message || "No se pudo añadir al carrito.",
          "error"
        );
      }
    },
    error: function (jqXHR, textStatus) {
      Swal.fire(
        "Error!",
        "Error al comunicar con el servidor: " + textStatus,
        "error"
      );
    },
  });
}

// Consultar contenido del carrito para el modal
function consultar_carrito() {
  $.ajax({
    type: "POST",
    url: "/login_1/controller/auxiliar/modal_carrito.php",
    success: function (data) {
      document.getElementById("mi_carrito").innerHTML = data;
    },
    error: function (jqXHR, textStatus, errorThrown) {
      document.getElementById("mi_carrito").innerHTML =
        "<p>Error al cargar el carrito.</p>";
      console.error("Error al consultar carrito:", textStatus, errorThrown);
    },
  });
}

// Actualizar conteo de productos en el navbar
function count_carrito() {
  $.ajax({
    type: "POST",
    url: "/login_1/controller/auxiliar/count_carrito.php",
    dataType: "json",
    success: function (response) {
      document.getElementById("count_carrito").innerHTML =
        response.status === "OK" ? response.count : "Error";
    },
    error: function () {
      document.getElementById("count_carrito").innerHTML = "?";
    },
  });
}

// Vaciar completamente el carrito
function borrar_carrito() {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "¡Esto vaciará tu carrito!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, vaciarlo",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      $.ajax({
        type: "POST",
        url: "/login_1/controller/auxiliar/borrarcarro.php",
        dataType: "json",
        success: function (response) {
          if (response.status === "OK") {
            Swal.fire("¡Vaciado!", "Tu carrito ha sido vaciado.", "success");
            consultar_carrito();
            count_carrito();
          } else {
            Swal.fire(
              "Error",
              response.message || "Error desconocido.",
              "error"
            );
          }
        },
        error: function () {
          Swal.fire("Error!", "Error al vaciar el carrito.", "error");
        },
      });
    }
  });
}
