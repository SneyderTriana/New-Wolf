<?php
require_once "config/conexion.php"; // Incluye el archivo de conexión a la base de datos

class Usuario
{
    private $db; // Propiedad para almacenar la conexión a la base de datos

    public function __construct()
    {
        // Constructor: crea una nueva instancia de 'conexion' y asigna la conexión a $db
        $this->db = (new conexion())->conn;
    }

    // Método para iniciar sesión de un usuario
    public function login($username, $password)
    {
        // Prepara la consulta SQL para buscar un usuario por su nombre de usuario
        $query = "SELECT * FROM usuarios WHERE username = :username";
        $stmt = $this->db->prepare($query);
        // Vincula el parámetro :username
        $stmt->bindParam(":username", $username);
        // Ejecuta la consulta
        $stmt->execute();

        // Obtiene la fila del usuario como un array asociativo
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica si se encontró el usuario y si la contraseña coincide (usando password_verify para hashes)
        if ($user && password_verify($password, $user['password'])) {
            return $user; // Devuelve los datos del usuario si la autenticación es exitosa
        }

        return false; // Devuelve false si la autenticación falla
    }

    // Método para registrar un nuevo usuario
    public function registrar($username, $password, $nombre, $correo, $genero, $fechaNacimiento)
    {
        // Genera un hash de la contraseña usando BCRYPT
        $hash = password_hash($password, PASSWORD_BCRYPT);
        // Prepara la consulta SQL para insertar un nuevo usuario
        $query = "INSERT INTO usuarios (username, password, nombre, correo, genero, fechaNacimiento) 
                  VALUES (:username, :password, :nombre, :correo, :genero, :fechaNacimiento)";
        $stmt = $this->db->prepare($query);
        // Vincula todos los parámetros
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hash);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":correo", $correo);
        $stmt->bindParam(":genero", $genero);
        $stmt->bindParam(":fechaNacimiento", $fechaNacimiento);
        // Ejecuta la consulta y devuelve true en caso de éxito, false en caso de fallo
        return $stmt->execute();
    }
}
?>