<?php

class conexion
{
    // Propiedades privadas para los detalles de la conexión a la base de datos
    private $host = "localhost"; // Dirección del servidor de la base de datos
    private $dbname = "login_db"; // Nombre de la base de datos
    private $user = "root"; // Nombre de usuario para la conexión
    private $password = ""; // Contraseña del usuario
    public $conn; // Propiedad pública para almacenar el objeto de conexión PDO

    // Constructor de la clase, se ejecuta al crear una nueva instancia de 'conexion'
    public function __construct()
    {
        try {
            // Intenta establecer la conexión utilizando PDO
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->user, $this->password);
            // Configura el modo de error de PDO para lanzar excepciones en caso de problemas
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            // Captura cualquier excepción PDO que ocurra durante la conexión
            // Detiene la ejecución del script y muestra un mensaje de error
            die("Error en la conexion: " . $e->getMessage());
        }
    }

}
?>

<?php
// conexion.php

$host = 'localhost'; // O la IP de tu servidor de base de datos
$usuario = 'root';   // Tu usuario de MySQL (por defecto 'root' en XAMPP)
$password = '';      // Tu contraseña de MySQL (por defecto vacía en XAMPP)
$nombre_db = 'login_db'; // ¡Asegúrate de que este sea el nombre correcto de tu base de datos!

// Crear conexión
$conexion = mysqli_connect($host, $usuario, $password, $nombre_db);

// Verificar conexión
if (!$conexion) {
    die("Error de conexión a la base de datos: " . mysqli_connect_error());
}

// Opcional: Establecer el juego de caracteres a UTF-8
mysqli_set_charset($conexion, "utf8");
?>



<?php
// Database credentials
$host = "localhost";    // The hostname or IP address of your database server
$dbuser = "root";       // Your database username (often 'root' for XAMPP defaults)
$dbpwd = "";            // Your database password (often empty '' for XAMPP defaults)
$db = "login_db";      // The name of your database

// Establish a new MySQLi connection
// Aseguramos que la variable de conexión sea $mysqli
$mysqli = new mysqli($host, $dbuser, $dbpwd, $db);

// Check for connection errors
if ($mysqli->connect_error) {
    // If there's an error, stop execution and display a detailed error message for debugging.
    die("<h1>Error Crítico de Base de Datos</h1>" .
        "<p>La conexión a la base de datos no está disponible. Verifique lib/config.php.</p>" .
        "<p>Detalles del error de MySQLi: " . $mysqli->connect_error . "</p>" .
        "<p>Código de error: " . $mysqli->connect_errno . "</p>");
}

// Optional: Set the character set to UTF-8 for proper handling of special characters (accents, ñ, etc.)
$mysqli->set_charset("utf8");

// You can remove this line in production; it's just for testing the connection.
// echo "Conexión exitosa";

?>