<?php
include __DIR__ . '/../config/conexion.php'; // Incluye la conexión a la base de datos mysqli ($mysqli)
include __DIR__ . '../lib/php/socialnetwork-lib.php'; // Asegúrate de que no use funciones mysql_*

// Muestra errores para depuración (¡desactívalo en producción!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica la conexión a la base de datos
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Error de conexión a la base de datos: " . (isset($mysqli) ? $mysqli->connect_error : "La conexión a MySQLi no está definida en lib/config.php"));
}

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Obtener ID de usuario logueado de la sesión de forma segura
$session_user_id = $_SESSION['id'] ?? null;
$session_user_avatar = $_SESSION['avatar'] ?? 'default.jpg'; // Valor por defecto si no está seteado
$session_username = $_SESSION['usuario'] ?? 'Usuario Desconocido'; // Valor por defecto

// Asegúrate de que 'likes.js' y el script de comentarios AJAX funcionen correctamente con los nuevos IDs/clases si los cambias.
// También, el archivo 'agregarcomentario.php' debe estar actualizado para usar mysqli.
?>
<script type="text/javascript" src="js/likes.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $(".enviar-btn").keypress(function(event) {
        if (event.which == 13) {
            var getpID = $(this).parent().attr('id').replace('record-', '');

            // Obtener valores de campos ocultos del formulario
            var usuario = $("#usuario-" + getpID).val();
            var comentario = $("#comentario-" + getpID).val();
            var publicacion = getpID;
            var avatar = $("#avatar-" + getpID).val();
            var nombre = $("#nombre-" + getpID).val();

            var now = new Date();
            var date_show = now.getDate() + '-' + (now.getMonth() + 1) + '-' + now.getFullYear() + ' ' + now.getHours() + ':' + ('0' + now.getMinutes()).slice(-2) + ':' + ('0' + now.getSeconds()).slice(-2);

            if (comentario.trim() === '') {
                alert('Debes añadir un comentario');
                return false;
            }

            var dataString = 'usuario=' + encodeURIComponent(usuario) + '&comentario=' + encodeURIComponent(comentario) + '&publicacion=' + encodeURIComponent(publicacion);

            $.ajax({
                type: "POST",
                url: "agregarcomentario.php",
                data: dataString,
                success: function() {
                    $('#nuevocomentario' + getpID).append('<div class="box-comment"><img class="img-circle img-sm" src="avatars/' + avatar + '"><div class="comment-text"><span class="username"> ' + nombre + '<span class="text-muted pull-right">' + date_show + '</span></span>' + comentario + '</div></div>');
                    // Limpiar el campo de comentario después de enviar
                    $("#comentario-" + getpID).val('');
                },
                error: function(xhr, status, error) {
                    console.error("Error al agregar comentario:", status, error);
                    alert("Error al agregar el comentario. Por favor, inténtalo de nuevo.");
                }
            });
            return false;
        }
    });
});
</script>

<?php
$CantidadMostrar = 5;
// Sanea y valida el ID del usuario del GET
$aid = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);

if ($aid === false || $aid === null || $aid <= 0) {
    echo "<p>ID de usuario inválido.</p>";
    exit(); // Detiene la ejecución si el ID no es válido
}

// Contar el total de registros
$stmt_total_reg = $mysqli->prepare("SELECT COUNT(*) FROM publicaciones WHERE usuario = ?");
if ($stmt_total_reg) {
    $stmt_total_reg->bind_param("i", $aid);
    $stmt_total_reg->execute();
    $stmt_total_reg->bind_result($totalr);
    $stmt_total_reg->fetch();
    $stmt_total_reg->close();
} else {
    echo "<p>Error al preparar la consulta de conteo de publicaciones: " . $mysqli->error . "</p>";
    $totalr = 0; // Asegura que $totalr tenga un valor en caso de error
}

$TotalRegistro = ceil($totalr / $CantidadMostrar);

// Validar la variable de paginación
$compag = (int)($_GET['pag'] ?? 1);
if ($compag < 1) {
    $compag = 1;
} elseif ($compag > $TotalRegistro && $TotalRegistro > 0) {
    $compag = $TotalRegistro;
}

$IncrimentNum = (($compag + 1) <= $TotalRegistro) ? ($compag + 1) : 0;

// Consulta SQL para obtener las publicaciones
$offset = ($compag - 1) * $CantidadMostrar;
$stmt_publicaciones = $mysqli->prepare("SELECT id_pub, usuario, contenido, imagen, fecha, likes FROM publicaciones WHERE usuario = ? ORDER BY id_pub DESC LIMIT ?, ?");

if ($stmt_publicaciones) {
    $stmt_publicaciones->bind_param("iii", $aid, $offset, $CantidadMostrar);
    $stmt_publicaciones->execute();
    $result_publicaciones = $stmt_publicaciones->get_result();

    while ($lista = $result_publicaciones->fetch_assoc()) {
        $userid = $lista['usuario']; // Ya está saneado, viene de la DB

        // Obtener datos del usuario de la publicación
        $stmt_usuario = $mysqli->prepare("SELECT id_use, usuario, avatar FROM usuarios WHERE id_use = ?");
        $use = ['id_use' => '', 'usuario' => 'Desconocido', 'avatar' => 'default.jpg']; // Valores por defecto
        if ($stmt_usuario) {
            $stmt_usuario->bind_param("i", $userid);
            $stmt_usuario->execute();
            $result_usuario = $stmt_usuario->get_result();
            if ($result_usuario->num_rows > 0) {
                $use = $result_usuario->fetch_assoc();
            }
            $stmt_usuario->close();
        }

        // Obtener datos de la foto si existe
        $fot = ['ruta' => '']; // Valor por defecto
        if ($lista['imagen'] != 0) {
            $stmt_fotos = $mysqli->prepare("SELECT ruta FROM fotos WHERE publicacion = ?");
            if ($stmt_fotos) {
                $stmt_fotos->bind_param("i", $lista['id_pub']);
                $stmt_fotos->execute();
                $result_fotos = $stmt_fotos->get_result();
                if ($result_fotos->num_rows > 0) {
                    $fot = $result_fotos->fetch_assoc();
                }
                $stmt_fotos->close();
            }
        }
?>
    <div class="box box-widget">
        <div class="box-header with-border">
            <div class="user-block">
                <img class="img-circle" src="avatars/<?php echo htmlspecialchars($use['avatar']); ?>" alt="User Image">
                <span class="description" onclick="location.href='perfil.php?id=<?php echo htmlspecialchars($use['id_use']); ?>';" style="cursor:pointer; color: #3C8DBC;"><?php echo htmlspecialchars($use['usuario']); ?></span>
                <span class="description"><?php echo htmlspecialchars($lista['fecha']); ?></span>
            </div>
            <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>
        </div>
        <div class="box-body">
            <p><?php echo htmlspecialchars($lista['contenido']); ?></p>

            <?php if ($lista['imagen'] != 0 && !empty($fot['ruta'])) { ?>
                <img src="publicaciones/<?php echo htmlspecialchars($fot['ruta']); ?>" width="100%">
            <?php } ?>

            <br><br>
            <?php
            // Contar comentarios
            $numcomen = 0;
            $stmt_num_comen = $mysqli->prepare("SELECT COUNT(*) FROM comentarios WHERE publicacion = ?");
            if ($stmt_num_comen) {
                $stmt_num_comen->bind_param("i", $lista['id_pub']);
                $stmt_num_comen->execute();
                $stmt_num_comen->bind_result($numcomen);
                $stmt_num_comen->fetch();
                $stmt_num_comen->close();
            }
            ?>
            <ul class="list-inline">
                <?php
                // Verificar si el usuario actual ya dio "me gusta"
                $user_liked = false;
                if ($session_user_id !== null) {
                    $stmt_like_check = $mysqli->prepare("SELECT id FROM likes WHERE post = ? AND usuario = ?");
                    if ($stmt_like_check) {
                        $stmt_like_check->bind_param("ii", $lista['id_pub'], $session_user_id);
                        $stmt_like_check->execute();
                        $stmt_like_check->store_result();
                        if ($stmt_like_check->num_rows > 0) {
                            $user_liked = true;
                        }
                        $stmt_like_check->close();
                    }
                }
                ?>
                <li>
                    <div class="btn btn-default btn-xs like" id="<?php echo htmlspecialchars($lista['id_pub']); ?>">
                        <i class="fa fa-thumbs-o-up"></i> <?php echo $user_liked ? 'No me gusta' : 'Me gusta'; ?>
                    </div>
                    <span id="likes_<?php echo htmlspecialchars($lista['id_pub']); ?>"> (<?php echo htmlspecialchars($lista['likes']); ?>)</span>
                </li>

                <li class="pull-right">
                    <span href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comentarios (<?php echo htmlspecialchars($numcomen); ?>)</span>
                </li>
            </ul>
        </div>
        <div class="box-footer box-comments">
            <?php
            // Mostrar los últimos 2 comentarios
            $stmt_comentarios = $mysqli->prepare("SELECT id_com, usuario, comentario, fecha FROM comentarios WHERE publicacion = ? ORDER BY id_com DESC LIMIT 2");
            if ($stmt_comentarios) {
                $stmt_comentarios->bind_param("i", $lista['id_pub']);
                $stmt_comentarios->execute();
                $result_comentarios = $stmt_comentarios->get_result();
                while ($com = $result_comentarios->fetch_assoc()) {
                    // Obtener datos del usuario del comentario
                    $usuarioc = ['usuario' => 'Desconocido', 'avatar' => 'default.jpg']; // Valores por defecto
                    $stmt_usuarioc = $mysqli->prepare("SELECT usuario, avatar FROM usuarios WHERE id_use = ?");
                    if ($stmt_usuarioc) {
                        $stmt_usuarioc->bind_param("i", $com['usuario']);
                        $stmt_usuarioc->execute();
                        $result_usuarioc = $stmt_usuarioc->get_result();
                        if ($result_usuarioc->num_rows > 0) {
                            $usuarioc = $result_usuarioc->fetch_assoc();
                        }
                        $stmt_usuarioc->close();
                    }
            ?>
                    <div class="box-comment">
                        <img class="img-circle img-sm" src="avatars/<?php echo htmlspecialchars($usuarioc['avatar']); ?>">
                        <div class="comment-text">
                            <span class="username">
                                <?php echo htmlspecialchars($usuarioc['usuario']); ?>
                                <span class="text-muted pull-right"><?php echo htmlspecialchars($com['fecha']); ?></span>
                            </span>
                            <?php echo htmlspecialchars($com['comentario']); ?>
                        </div>
                    </div>
            <?php
                }
                $stmt_comentarios->close();
            }
            ?>

            <?php if ($numcomen > 2) { ?>
                <br>
                <center><span onclick="location.href='publicacion.php?id=<?php echo htmlspecialchars($lista['id_pub']); ?>';" style="cursor:pointer; color: #3C8DBC;">Ver todos los comentarios</span></center>
            <?php } ?>

            <div id="nuevocomentario<?php echo htmlspecialchars($lista['id_pub']); ?>"></div>
            <br>
            <form method="post" action="">
                <label id="record-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="text" class="enviar-btn form-control input-sm" style="width: 100%;" placeholder="Escribe un comentario" name="comentario" id="comentario-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="hidden" name="usuario" value="<?php echo htmlspecialchars($session_user_id); ?>" id="usuario-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="hidden" name="publicacion" value="<?php echo htmlspecialchars($lista['id_pub']); ?>" id="publicacion-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="hidden" name="avatar" value="<?php echo htmlspecialchars($session_user_avatar); ?>" id="avatar-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                    <input type="hidden" name="nombre" value="<?php echo htmlspecialchars($session_username); ?>" id="nombre-<?php echo htmlspecialchars($lista['id_pub']); ?>">
                </label>
            </form>
        </div>
    </div>
<?php
    }
    $stmt_publicaciones->close(); // Cierra la sentencia de publicaciones
} else {
    echo "<p>Error al preparar la consulta de publicaciones: " . $mysqli->error . "</p>";
}
?>

<br><br>
<?php
if ($IncrimentNum > 0) {
    echo "<a href=\"miactividad.php?id=" . htmlspecialchars($aid) . "&pag=" . htmlspecialchars($IncrimentNum) . "\">Siguiente</a>";
}
?>

<script>
    $(document).ready(function() {
        $('.scroll').jscroll({
            loadingHtml: '<img src="images/invisible.png" alt="Loading" />'
        });
    });
</script>