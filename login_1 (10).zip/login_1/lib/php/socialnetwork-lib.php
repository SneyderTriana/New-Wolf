<?php
// Se asume que config.php o similar ya estableció la conexión MySQLi.
// Por ejemplo:
// $mysqli = new mysqli("localhost", "usuario", "contraseña", "nombre_base_datos");
// if ($mysqli->connect_errno) {
//     die("Fallo al conectar a MySQL: " . $mysqli->connect_error);
// }
// También podrías necesitar session_start() si no se ha llamado aún.
// session_start();

// Define la función Headerb que ahora espera el objeto $mysqli.
function Headerb($mysqli) 
{
    // Asegura que $_SESSION['id'] esté definido, si no, usa null.
    $current_user_id = $_SESSION['id'] ?? null;
    $cuantas = 0; // Inicializa el contador de notificaciones.

    // Procede solo si hay un ID de usuario en sesión.
    if ($current_user_id) {
        // Prepara la consulta para obtener notificaciones no leídas.
        // La línea 21 del reporte de error se refiere a esta llamada a prepare().
        $stmt_noti = $mysqli->prepare("SELECT id_not, user1, tipo, id_pub FROM notificaciones WHERE user2 = ? AND leido = '0' ORDER BY id_not DESC");

        // Verifica si la preparación de la consulta fue exitosa.
        if ($stmt_noti) {
            // Vincula el parámetro: "i" indica que es un entero.
            $stmt_noti->bind_param("i", $current_user_id); 
            // Ejecuta la consulta.
            $stmt_noti->execute();
            // Obtiene el resultado.
            $result_noti = $stmt_noti->get_result();
            // Cuenta el número de filas (notificaciones).
            $cuantas = $result_noti->num_rows;

            // Obtiene todas las notificaciones en un array asociativo para iterar.
            $notifications = $result_noti->fetch_all(MYSQLI_ASSOC);
            // Cierra el statement.
            $stmt_noti->close();
        } else {
            // Registra un error si la preparación falla.
            error_log("Error al preparar el statement de notificaciones: " . $mysqli->error);
        }
    }
?>
<header class="main-header">

    <a href="index.php" class="logo">
      <span class="logo-lg"><b>RED</b>SOCIAL</span>
    </a>

    <nav class="navbar navbar-static-top">
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning"><?php echo htmlspecialchars($cuantas); ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Tienes <?php echo htmlspecialchars($cuantas); ?> notificaciones</li>
              <li>
                <ul class="menu">

                <?php
                // Muestra las notificaciones si hay alguna.
                if ($cuantas > 0) {
                    foreach ($notifications as $no) {
                        // Prepara la consulta para obtener el usuario que envió la notificación.
                        $stmt_users = $mysqli->prepare("SELECT usuario FROM usuarios WHERE id_use = ?");
                        // Valor predeterminado en caso de que no se encuentre el usuario.
                        $usa = ['usuario' => 'Usuario Desconocido']; 
                        // Verifica si la preparación fue exitosa.
                        if ($stmt_users) {
                            // Vincula el parámetro.
                            $stmt_users->bind_param("i", $no['user1']); 
                            // Ejecuta la consulta.
                            $stmt_users->execute();
                            // Obtiene el resultado.
                            $result_users = $stmt_users->get_result();
                            // Si se encuentra el usuario, actualiza $usa.
                            if ($result_users->num_rows > 0) {
                                $usa = $result_users->fetch_assoc();
                            }
                            // Cierra el statement.
                            $stmt_users->close();
                        } else {
                            // Registra un error si la preparación falla.
                            error_log("Error al preparar el statement de usuarios: " . $mysqli->error);
                        }
                ?>
                    <li>
                        <a href="publicacion.php?id=<?php echo htmlspecialchars($no['id_pub']); ?>">
                            <i class="fa fa-users text-aqua"></i> El usuario <?php echo htmlspecialchars($usa['usuario']); ?> <?php echo htmlspecialchars($no['tipo']); ?> tu publicación
                        </a>
                    </li>
                <?php
                    }
                } else {
                    // Mensaje si no hay notificaciones.
                    echo '<li><a href="#"><i class="fa fa-info-circle"></i> No tienes nuevas notificaciones</a></li>';
                }
                ?>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todas las notificaciones</a></li>
            </ul>
          </li>

          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="avatars/<?php echo htmlspecialchars($_SESSION['avatar'] ?? 'default.jpg'); ?>" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo htmlspecialchars(ucwords($_SESSION['usuario'] ?? 'Invitado')); ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="avatars/<?php echo htmlspecialchars($_SESSION['avatar'] ?? 'default.jpg'); ?>" class="img-circle" alt="User Image">

                <p>
                  <?php echo htmlspecialchars(ucwords($_SESSION['usuario'] ?? 'Invitado')); ?>
                  <small>Miembro desde Mayo 31</small>
                </p>
              </li>
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-6 text-center">
                    <a href="#">Seguidores</a>
                  </div>
                  <div class="col-xs-6 text-center">
                    <a href="#">Seguidos</a>
                  </div>
                </div>
                </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="editarperfil.php?id=<?php echo htmlspecialchars($_SESSION['id'] ?? '');?>" class="btn btn-default btn-flat">Editar perfil</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Cerrar sesión</a>
                </div>
              </li>
            </ul>
          </li>
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>

    </nav>
  </header>
<?php
} // Fin de la función Headerb

// Define la función Side.
function Side()
{
    // Asegura que las variables de sesión estén definidas.
    $avatar = $_SESSION['avatar'] ?? 'default.jpg';
    $usuario = $_SESSION['usuario'] ?? 'Invitado';
?>
<aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left">
          <img src="avatars/<?php echo htmlspecialchars($avatar); ?>" width="50" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo htmlspecialchars(ucwords($usuario)); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Encuentra a tus amigos">
                <span class="input-group-btn">
                  <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                  </button>
                </span>
        </div>
      </form>
      <ul class="sidebar-menu">
        <li class="header">MENÚ DE NAVEGACIÓN</li>
        <li>
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Noticias</span>
          </a>
        </li>
        <li>
          <a href="mensajes.php">
            <i class="fa fa-comment"></i> <span>Chat</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green">1</small> </span>
          </a>
        </li>
        <li>
          <a href="index.php">
            <i class="fa fa-user"></i> <span>Mis seguidores</span>
          </a>
        </li>
        <li>
          <a href="index.php">
            <i class="fa fa-arrow-right"></i> <span>Seguidos</span>
          </a>
        </li>
        <li>
          <a href="index.php">
            <i class="fa fa-heart"></i> <span>Me gusta</span>
          </a>
        </li>
            </ul>
          </li>
      </ul>
    </section>
    </aside>
<?php
} // Fin de la función Side
?>