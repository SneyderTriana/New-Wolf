<link rel="stylesheet" href="../assets/styles/style.css">
<?php
include '../config/conexion.php'; // Conexión a la base de datos

require_once __DIR__ . '/../config/addressDocument.php'; // Rutas definidas
require_once HEADER; // Cabecera

// Mostrar errores durante el desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verificar conexión a la base de datos
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Error crítico: No se pudo conectar a la base de datos.");
}

// Obtener datos del usuario desde la sesión
$session_user_id = $_SESSION['id'] ?? null;
$session_user_avatar = $_SESSION['avatar'] ?? 'default.jpg';
$session_username = $_SESSION['usuario'] ?? 'Usuario Desconocido';

// Procesar publicación
if (isset($_POST['publicar'])) {
    $publicacion_contenido = trim($_POST['publicacion'] ?? '');
    $imagen_cargada = false;
    $foto_nombre = '';
    $id_foto_insertada = 0;
    $id_album_publicaciones = 0;

    if (empty($publicacion_contenido) && (!isset($_FILES['foto']) || $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE)) {
        echo '<div class="alert alert-danger">Debes escribir algo o subir una imagen.</div>';
    } else {
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $file_tmp_name = $_FILES['foto']['tmp_name'];
            $file_name = $_FILES['foto']['name'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array($file_ext, $allowed_ext)) {
                $unique_name = uniqid('pub_', true) . '.' . $file_ext;
                $destination = "publicaciones/" . $unique_name;

                if (move_uploaded_file($file_tmp_name, $destination)) {
                    $foto_nombre = $unique_name;
                    $imagen_cargada = true;
                } else {
                    echo '<div class="alert alert-danger">Error al subir la imagen.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">Formato de imagen no permitido.</div>';
            }
        }

        if (empty($publicacion_contenido) && !$imagen_cargada) {
            echo '<div class="alert alert-danger">Debes escribir algo o subir una imagen.</div>';
        } else {
            $next_pub_id = 0;
            $result = $mysqli->query("SHOW TABLE STATUS LIKE 'publicaciones'");
            if ($result) {
                $data = $result->fetch_assoc();
                $next_pub_id = $data['Auto_increment'];
                $result->free();
            }

            $stmt_album = $mysqli->prepare("SELECT id_alb FROM albumes WHERE usuario = ? AND nombre = 'Publicaciones'");
            if ($stmt_album) {
                $stmt_album->bind_param("i", $session_user_id);
                $stmt_album->execute();
                $stmt_album->bind_result($id_album_publicaciones);
                $stmt_album->fetch();
                $stmt_album->close();
            }

            if ($id_album_publicaciones === 0) {
                $stmt_create_album = $mysqli->prepare("INSERT INTO albumes (usuario, fecha, nombre) VALUES (?, NOW(), 'Publicaciones')");
                if ($stmt_create_album) {
                    $stmt_create_album->bind_param("i", $session_user_id);
                    $stmt_create_album->execute();
                    $id_album_publicaciones = $mysqli->insert_id;
                    $stmt_create_album->close();
                } else {
                    echo '<div class="alert alert-danger">Error al crear el álbum: ' . $mysqli->error . '</div>';
                }
            }

            if ($imagen_cargada && $id_album_publicaciones !== 0) {
                $stmt_insert_foto = $mysqli->prepare("INSERT INTO fotos (usuario, fecha, ruta, album, publicacion) VALUES (?, NOW(), ?, ?, ?)");
                if ($stmt_insert_foto) {
                    $stmt_insert_foto->bind_param("isii", $session_user_id, $foto_nombre, $id_album_publicaciones, $next_pub_id);
                    if ($stmt_insert_foto->execute()) {
                        $id_foto_insertada = $mysqli->insert_id;
                    } else {
                        echo '<div class="alert alert-danger">Error al guardar la foto: ' . $stmt_insert_foto->error . '</div>';
                    }
                    $stmt_insert_foto->close();
                } else {
                    echo '<div class="alert alert-danger">Error al preparar la inserción de foto: ' . $mysqli->error . '</div>';
                }
            }

            if ($next_pub_id > 0) {
                $imagen_val = ($id_foto_insertada > 0) ? $id_foto_insertada : 0;
                $album_val = ($id_album_publicaciones > 0) ? $id_album_publicaciones : 0;

                $stmt_insert_pub = $mysqli->prepare("INSERT INTO publicaciones (usuario, fecha, contenido, imagen, album, comentarios) VALUES (?, NOW(), ?, ?, ?, 1)");
                if ($stmt_insert_pub) {
                    $stmt_insert_pub->bind_param("isii", $session_user_id, $publicacion_contenido, $imagen_val, $album_val);
                    if ($stmt_insert_pub->execute()) {
                        echo '<script>window.location="index.php"</script>';
                        exit();
                    } else {
                        echo '<div class="alert alert-danger">Error al insertar publicación: ' . $stmt_insert_pub->error . '</div>';
                    }
                    $stmt_insert_pub->close();
                } else {
                    echo '<div class="alert alert-danger">Error al preparar la publicación: ' . $mysqli->error . '</div>';
                }
            } else {
                echo '<div class="alert alert-danger">No se pudo obtener el ID de publicación.</div>';
            }
        }
    }
}
?>

<script type="text/javascript" src="js/likes.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script type="text/javascript">
    $(document).ready(function () {

        function htmlspecialchars(str) {
            if (typeof str !== 'string') return str;
            var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
            return str.replace(/[&<>"']/g, function (m) { return map[m]; });
        }

        $(".enviar-btn").keypress(function (event) {
            if (event.which == 13) {
                event.preventDefault();

                var getpID = $(this).parent().attr('id').replace('record-', '');
                var usuario = $("input#usuario").val();
                var comentario = $("#comentario-" + getpID).val();
                var publicacion = getpID;
                var avatar = $("input#avatar").val();
                var nombre = $("input#nombre").val();

                var now = new Date();
                var date_show = now.getDate() + '-' + (now.getMonth() + 1) + '-' + now.getFullYear() + ' ' +
                    now.getHours().toString().padStart(2, '0') + ':' +
                    now.getMinutes().toString().padStart(2, '0') + ':' +
                    now.getSeconds().toString().padStart(2, '0');

                if (comentario.trim() === '') {
                    alert('Debes añadir un comentario');
                    return false;
                }

                var dataString = 'usuario=' + encodeURIComponent(usuario) +
                    '&comentario=' + encodeURIComponent(comentario) +
                    '&publicacion=' + encodeURIComponent(publicacion);

                $.ajax({
                    type: "POST",
                    url: "agregarcomentario.php",
                    data: dataString,
                    success: function (response) {
                        if (response.trim() === "success") {
                            $('#nuevocomentario' + getpID).append(
                                '<div class="box-comment">' +
                                '<img class="img-circle img-sm" src="avatars/' + htmlspecialchars(avatar) + '" alt="Avatar">' +
                                '<div class="comment-text">' +
                                '<span class="username">' + htmlspecialchars(nombre) +
                                '<span class="text-muted pull-right">' + date_show + '</span></span>' +
                                htmlspecialchars(comentario) +
                                '</div>' +
                                '</div>'
                            );
                            $("#comentario-" + getpID).val('');
                        } else {
                            alert("Error al agregar comentario: " + response);
                            console.error("Respuesta del servidor:", response);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.error("Error AJAX:", textStatus, errorThrown);
                        alert("Error de comunicación al enviar el comentario.");
                    }
                });

                return false;
            }
        });
    });
</script>

<?php
$CantidadMostrar = 5;
$compag = (int) (!isset($_GET['pag'])) ? 1 : $_GET['pag'];

$stmt_total_reg = $mysqli->prepare("SELECT COUNT(*) AS total FROM publicaciones");
if (!$stmt_total_reg->execute()) {
    die("Error al contar publicaciones: " . $mysqli->error);
}
$result_total_reg = $stmt_total_reg->get_result();
$row_total_reg = $result_total_reg->fetch_assoc();
$totalr = $row_total_reg['total'];
$stmt_total_reg->close();

$TotalRegistro = ceil($totalr / $CantidadMostrar);
$IncrimentNum = (($compag + 1) <= $TotalRegistro) ? ($compag + 1) : 0;
?>

<div class="content-wrapper">
    <section class="content">
        <script type="text/javascript">
            function validarn(e) {
                var tecla = (document.all) ? e.keyCode : e.which;
                if (tecla === 8 || tecla === 9 || tecla === 11) return true; // Backspace, Tab, Vertical Tab
                var patron = /[A-Za-zñ!#$%&()=?¿¡*+0-9-_á-úÁ-Ú :;,.]/;
                var te = String.fromCharCode(tecla);
                return patron.test(te);
            }
        </script>
        <div class="row">
            <div class="col-md-8">
                <div class="row">

                    <div class="col-md-12">
                        <div class="box box-primary direct-chat direct-chat-warning">
                            <div class="box-header with-border">
                                <h3 class="box-title">¿Qué estás pensando?</h3>


                                </button>
                            </div>

                            <div class="box-footer">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="input-group">
                                        <textarea name="publicacion" onkeypress="return validarn(event)"
                                            placeholder="¿Qué estás pensando?" class="form-control" cols="80"
                                            rows="3"></textarea>
                                        <br>
                                        <input type="file" name="foto" id="file-1" class="inputfile inputfile-1"
                                            data-multiple-caption="{count} files selected" />


                                        <button type="submit" name="publicar"
                                            class="btn btn-primary btn-flat">Publicar</button>
                                        <br><br>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="scroll">
                    <?php
                    // Consulta para obtener las publicaciones con paginación
                    $offset = ($compag - 1) * $CantidadMostrar;
                    $consultavistas = "SELECT id_pub, usuario, contenido, fecha, imagen, likes FROM publicaciones ORDER BY id_pub DESC LIMIT ?, ?";
                    $stmt_publicaciones = $mysqli->prepare($consultavistas);
                    if (!$stmt_publicaciones) {
                        die("Error al preparar la consulta de publicaciones: " . $mysqli->error);
                    }
                    $stmt_publicaciones->bind_param("ii", $offset, $CantidadMostrar);
                    if (!$stmt_publicaciones->execute()) {
                        die("Error al ejecutar la consulta de publicaciones: " . $stmt_publicaciones->error);
                    }
                    $consulta = $stmt_publicaciones->get_result();

                    if ($consulta->num_rows === 0) {
                        echo "<p style='text-align: center; margin-top: 20px;'>No hay publicaciones disponibles.</p>";
                    }

                    while ($lista = $consulta->fetch_assoc()) {
                        $userid = $lista['usuario'];

                        // Obtener información del usuario de la publicación
                        $stmt_usuariob = $mysqli->prepare("SELECT id_use, username, avatar FROM usuarios WHERE id_use = ?");
                        if (!$stmt_usuariob) {
                            die("Error al preparar la consulta de usuario: " . $mysqli->error);
                        }
                        $stmt_usuariob->bind_param("i", $userid);
                        if (!$stmt_usuariob->execute()) {
                            die("Error al ejecutar la consulta de usuario: " . $stmt_usuariob->error);
                        }
                        $result_usuariob = $stmt_usuariob->get_result();
                        $use = $result_usuariob->fetch_assoc();
                        $stmt_usuariob->close();

                        // Obtener información de la foto si la publicación tiene imagen
                        $fot_ruta = ''; // Inicializar
                        if ($lista['imagen'] != 0) {
                            $stmt_fotos = $mysqli->prepare("SELECT ruta FROM fotos WHERE publicacion = ?");
                            if (!$stmt_fotos) {
                                die("Error al preparar la consulta de fotos: " . $mysqli->error);
                            }
                            $stmt_fotos->bind_param("i", $lista['id_pub']);
                            if (!$stmt_fotos->execute()) {
                                die("Error al ejecutar la consulta de fotos: " . $stmt_fotos->error);
                            }
                            $result_fotos = $stmt_fotos->get_result();
                            if ($row_foto = $result_fotos->fetch_assoc()) {
                                $fot_ruta = $row_foto['ruta'];
                            }
                            $stmt_fotos->close();
                        }
                        ?>
                        <div class="box box-widget publicacion-contenedor">
                            <div class="box-header with-border">
                                <div class="user-block">
                                    <img class="img-circle"
                                        src="avatars/<?php echo htmlspecialchars($use['avatar'] ?? 'default.png'); ?>"
                                        alt="User Image">
                                    <div>
                                        <span class="description"
                                            onclick="location.href='perfil.php?id=<?php echo htmlspecialchars($use['id_use'] ?? ''); ?>';"
                                            style="cursor:pointer;"><?php echo htmlspecialchars($use['username'] ?? 'Usuario Desconocido'); ?></span>
                                        <span
                                            class="description"><?php echo htmlspecialchars($lista['fecha'] ?? ''); ?></span>
                                    </div>
                                </div>
                                <div class="box-tools">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i
                                            class="fa fa-minus"></i></button>
                                </div>
                            </div>
                            <div class="box-body">
                                <p><?php echo htmlspecialchars($lista['contenido'] ?? ''); ?></p>

                                <?php if ($lista['imagen'] != 0 && !empty($fot_ruta)) { ?>
                                    <img class="img-responsive pad"
                                        src="publicaciones/<?php echo htmlspecialchars($fot_ruta); ?>"
                                        alt="Imagen de Publicación">
                                <?php } ?>

                                <?php
                                // Contar comentarios
                                $stmt_num_comen = $mysqli->prepare("SELECT COUNT(*) AS num_comen FROM comentarios WHERE publicacion = ?");
                                if (!$stmt_num_comen) {
                                    die("Error al preparar la consulta de conteo de comentarios: " . $mysqli->error);
                                }
                                $stmt_num_comen->bind_param("i", $lista['id_pub']);
                                if (!$stmt_num_comen->execute()) {
                                    die("Error al ejecutar la consulta de conteo de comentarios: " . $stmt_num_comen->error);
                                }
                                $result_num_comen = $stmt_num_comen->get_result();
                                $row_num_comen = $result_num_comen->fetch_assoc();
                                $numcomen = $row_num_comen['num_comen'];
                                $stmt_num_comen->close();
                                ?>
                                <ul class="list-inline">
                                    <?php
                                    // MODIFICACIÓN INICIADA AQUÍ
                                    $user_has_liked = false;
                                    if ($session_user_id !== null) { // Asegúrate de que el ID de sesión esté disponible
                                        $stmt_likes_query = $mysqli->prepare("SELECT id_lik FROM likes WHERE post = ? AND usuario = ?");
                                        if (!$stmt_likes_query) {
                                            die("Error al preparar la consulta de likes: " . $mysqli->error);
                                        }
                                        $stmt_likes_query->bind_param("ii", $lista['id_pub'], $session_user_id); // Usar $session_user_id
                                        if (!$stmt_likes_query->execute()) {
                                            die("Error al ejecutar la consulta de likes: " . $stmt_likes_query->error);
                                        }
                                        $result_likes_query = $stmt_likes_query->get_result();
                                        if ($result_likes_query->num_rows > 0) {
                                            $user_has_liked = true;
                                        }
                                        $stmt_likes_query->close();
                                    }
                                    // MODIFICACIÓN TERMINADA AQUÍ
                                
                                    if (!$user_has_liked) { ?>
                                        <li>
                                            <div class="btn btn-default btn-xs like"
                                                id="<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>"><i
                                                    class="fa fa-thumbs-o-up"></i> Me gusta </div><span
                                                id="likes_<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>">
                                                (<?php echo htmlspecialchars($lista['likes'] ?? 0); ?>)</span>
                                        </li>
                                    <?php } else { ?>
                                        <li>
                                            <div class="btn btn-default btn-xs dislike"
                                                id="<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>"><i
                                                    class="fa fa-thumbs-up"></i> No me gusta </div><span
                                                id="likes_<?php echo htmlspecialchars($lista['id_pub'] ?? 0); ?>">
                                                (<?php echo htmlspecialchars($lista['likes'] ?? 0); ?>)</span>
                                        </li> <?php } ?>

                                    <li class="pull-right">
                                        <span class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i>
                                            Comentarios
                                            (<?php echo htmlspecialchars($numcomen); ?>)</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="box-footer box-comments">
                                <?php
                                // Obtener los últimos 2 comentarios
                                $stmt_comentarios = $mysqli->prepare("SELECT id_com, usuario, comentario, fecha FROM comentarios WHERE publicacion = ? ORDER BY id_com DESC LIMIT 2");
                                if (!$stmt_comentarios) {
                                    die("Error al preparar la consulta de comentarios: " . $mysqli->error);
                                }
                                $stmt_comentarios->bind_param("i", $lista['id_pub']);
                                if (!$stmt_comentarios->execute()) {
                                    die("Error al ejecutar la consulta de comentarios: " . $stmt_comentarios->error);
                                }
                                $result_comentarios = $stmt_comentarios->get_result();

                                while ($com = $result_comentarios->fetch_assoc()) {
                                    $stmt_usuarioc = $mysqli->prepare("SELECT username, avatar FROM usuarios WHERE id_use = ?");
                                    if (!$stmt_usuarioc) {
                                        die("Error al preparar la consulta de usuario de comentario: " . $mysqli->error);
                                    }
                                    $stmt_usuarioc->bind_param("i", $com['usuario']);
                                    if (!$stmt_usuarioc->execute()) {
                                        die("Error al ejecutar la consulta de usuario de comentario: " . $stmt_usuarioc->error);
                                    }
                                    $result_usuarioc = $stmt_usuarioc->get_result();
                                    $usec = $result_usuarioc->fetch_assoc();
                                    $stmt_usuarioc->close();
                                    ?>
                                    <div class="box-comment">
                                        <img class="img-circle img-sm"
                                            src="avatars/<?php echo htmlspecialchars($usec['avatar'] ?? 'default.png'); ?>"
                                            alt="Avatar">
                                        <div class="comment-text">
                                            <span class="username">
                                                <?php echo htmlspecialchars($usec['username'] ?? 'Usuario Desconocido'); ?>
                                                <span
                                                    class="text-muted pull-right"><?php echo htmlspecialchars($com['fecha'] ?? ''); ?></span>
                                            </span>
                                            <?php echo htmlspecialchars($com['comentario'] ?? ''); ?>
                                        </div>
                                    </div>
                                <?php }
                                $stmt_comentarios->close();
                                ?>

                                <?php if ($numcomen > 2) { ?>
                                    <br>
                                    <center><span
                                            onclick="location.href='publicacion.php?id=<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>';"
                                            style="cursor:pointer; color: var(--blue-highlight);">Ver todos los
                                            comentarios</span></center>
                                <?php } ?>

                                <div id="nuevocomentario<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>"></div>
                                <form method="post" action="">
                                    <label id="record-<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>">
                                        <img class="img-responsive img-circle img-sm"
                                            src="avatars/<?php echo htmlspecialchars($session_user_avatar); ?>"
                                            alt="Imagen de Usuario">
                                        <div class="img-push">
                                            <input type="text" class="enviar-btn form-control input-sm"
                                                placeholder="Escribe un comentario" name="comentario"
                                                id="comentario-<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>">
                                            <input type="hidden" name="usuario"
                                                value="<?php echo htmlspecialchars($_SESSION['id'] ?? ''); ?>" id="usuario">
                                            <input type="hidden" name="publicacion"
                                                value="<?php echo htmlspecialchars($lista['id_pub'] ?? ''); ?>"
                                                id="publicacion">
                                            <input type="hidden" name="avatar"
                                                value="<?php echo htmlspecialchars($_SESSION['avatar'] ?? ''); ?>"
                                                id="avatar">
                                            <input type="hidden" name="nombre"
                                                value="<?php echo htmlspecialchars($_SESSION['usuario'] ?? ''); ?>"
                                                id="nombre">
                                        </div>
                                    </label>
                                </form>

                            </div>
                        </div>
                        <br>
                        <?php
                    }
                    $stmt_publicaciones->close();

                    // Paginación
                    if ($IncrimentNum > 0) {
                        echo "<a href=\"index.php?pag=" . htmlspecialchars($IncrimentNum) . "\" class='btn'>Siguiente</a>"; // Asegúrate de que la paginación apunte a index.php o el archivo principal
                    }
                    ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Solicitudes de amistad</h3>
                    </div>
                    <div class="box-body">
                        <ul class="products-list product-list-in-box">
                            <?php
                            // Solicitudes de amistad (mysqli)
                            // Aseguramos que $_SESSION['id'] exista antes de usarlo en la consulta
                            if ($session_user_id !== null) {
                                $stmt_amistad = $mysqli->prepare("SELECT id_ami, de FROM amigos WHERE para = ? AND estado = '0' ORDER BY id_ami DESC LIMIT 4");
                                if ($stmt_amistad) {
                                    $stmt_amistad->bind_param("i", $session_user_id); // Usar $session_user_id
                                    $stmt_amistad->execute();
                                    $result_amistad = $stmt_amistad->get_result();
                                    while ($am = $result_amistad->fetch_assoc()) {
                                        $stmt_user_solicitud = $mysqli->prepare("SELECT username, avatar, sexo FROM usuarios WHERE id_use = ?");
                                        $us = ['username' => 'Usuario Desconocido', 'avatar' => 'default.jpg', 'sexo' => 'No especificado'];
                                        if ($stmt_user_solicitud) {
                                            $stmt_user_solicitud->bind_param("i", $am['de']);
                                            $stmt_user_solicitud->execute();
                                            $result_user_solicitud = $stmt_user_solicitud->get_result();
                                            if ($result_user_solicitud->num_rows > 0) {
                                                $us = $result_user_solicitud->fetch_assoc();
                                            }
                                            $stmt_user_solicitud->close();
                                        }
                                        ?>
                                        <li class="item">
                                            <div class="product-img">
                                                <img src="avatars/<?php echo htmlspecialchars($us['avatar'] ?? 'default.jpg'); ?>"
                                                    alt="User Image">
                                            </div>
                                            <div class="product-info">
                                                <?php echo htmlspecialchars($us['username'] ?? 'Usuario Desconocido'); ?>
                                                <a
                                                    href="solicitud.php?action=aceptar&id=<?php echo htmlspecialchars($am['id_ami']); ?>"><span
                                                        class="label label-success pull-right">Aceptar</span></a>
                                                <a
                                                    href="solicitud.php?action=rechazar&id=<?php echo htmlspecialchars($am['id_ami']); ?>"><span
                                                        class="label label-danger pull-right">Rechazar</span></a>
                                                <span class="product-description">
                                                    <?php echo htmlspecialchars($us['sexo'] ?? 'No especificado'); ?>
                                                </span>
                                            </div>
                                        </li>
                                        <?php
                                    }
                                    $stmt_amistad->close();
                                } else {
                                    // Manejo de error si la preparación de la consulta de amistad falla
                                    echo '<p>Error al preparar la consulta de solicitudes de amistad.</p>';
                                }
                            } else {
                                echo '<p>Por favor, inicie sesión para ver las solicitudes de amistad.</p>';
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once FOOTER; ?>