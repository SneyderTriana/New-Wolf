<?php
// Inicia la sesión PHP. ES CRUCIAL QUE ESTO ESTÉ AL PRINCIPIO.


// Se incluye el archivo que define rutas absolutas del proyecto
require_once __DIR__ . '/../config/addressDocument.php';
require_once HEADER;
// Activar reporte de errores para depuración (desactivar en producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ----------------------------------------------------
// Explicación: Inclusión de archivos de configuración y librerías.
// Asegúrate de que estos archivos existan en la ruta 'lib/'.
// 'config/conexion.php' DEBE contener la conexión mysqli ($mysqli).
// ----------------------------------------------------
include '../config/conexion.php'; // Este archivo debe definir $mysqli para la conexión MySQLi
include '../lib/php/socialnetwork-lib.php'; // Asumo que contiene Headerb() y Side()

// ----------------------------------------------------
// Explicación: Redirección si el usuario no ha iniciado sesión.
// ----------------------------------------------------
// Verifica si la conexión $mysqli está disponible
if (!isset($mysqli) || $mysqli->connect_errno) {
    die("Error en la conexión a la base de datos.");
}

// ----------------------------------------------------
// Explicación: Procesar parámetros GET para el perfil.
// Se verifica si 'id' está presente en la URL.
// ----------------------------------------------------
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $pag = isset($_GET['perfil']) ? $_GET['perfil'] : 'miactividad'; // Si 'perfil' no está, usa 'miactividad'

    // ----------------------------------------------------
    // Explicación: Obtener información del usuario del perfil.
    // Uso de prepared statement para la consulta SQL.
    // ----------------------------------------------------
    $stmt_user = $mysqli->prepare("SELECT id_use, nombre, avatar, verificado, privada FROM usuarios WHERE id_use = ?");
    $stmt_user->bind_param("i", $id); // "i" indica que $id es un entero
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $use = $result_user->fetch_assoc(); // Usar fetch_assoc() para un array asociativo
    $stmt_user->close();

    // ----------------------------------------------------
    // Explicación: Obtener información de la relación de amistad.
    // Uso de prepared statement para la consulta SQL.
    // Es crucial agrupar las condiciones OR correctamente con paréntesis.
    // ----------------------------------------------------
    $stmt_amigos = $mysqli->prepare("SELECT * FROM amigos WHERE (de = ? AND para = ?) OR (de = ? AND para = ?)");
    $stmt_amigos->bind_param("iiii", $_SESSION['id'], $id, $id, $_SESSION['id']); // "iiii" para 4 enteros
    $stmt_amigos->execute();
    $result_amigos = $stmt_amigos->get_result();
    $ami = $result_amigos->fetch_assoc();
    $num_amigos = $result_amigos->num_rows; // Obtener el número de filas para el condicional
    $stmt_amigos->close();

    // ----------------------------------------------------
    // Explicación: Bloque de manejo de acciones de amistad (seguir/dejar de seguir).
    // Se utilizan prepared statements para todas las operaciones INSERT/DELETE.
    // ----------------------------------------------------
    if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Solo procesar si es una solicitud POST

        if (isset($_POST['seguir'])) {
            $stmt_add = $mysqli->prepare("INSERT INTO amigos (de, para, fecha, estado) VALUES (?, ?, NOW(), '0')");
            $stmt_add->bind_param("ii", $_SESSION['id'], $id);
            if ($stmt_add->execute()) {
                // Éxito al enviar solicitud
            } else {
                echo "Error al enviar solicitud de amistad: " . $stmt_add->error;
            }
            $stmt_add->close();
            // Redirigir siempre después de una acción POST exitosa para evitar reenvío del formulario
            header("Location: perfil.php?id=" . $id);
            exit();
        }

        if (isset($_POST['seguirdirecto'])) {
            $stmt_add = $mysqli->prepare("INSERT INTO amigos (de, para, fecha, estado) VALUES (?, ?, NOW(), '1')");
            $stmt_add->bind_param("ii", $_SESSION['id'], $id);
            if ($stmt_add->execute()) {
                // Éxito al seguir directamente
            } else {
                echo "Error al seguir directamente: " . $stmt_add->error;
            }
            $stmt_add->close();
            header("Location: perfil.php?id=" . $id);
            exit();
        }

        if (isset($_POST['dejarseguir'])) {
            $stmt_delete = $mysqli->prepare("DELETE FROM amigos WHERE (de = ? AND para = ?) OR (de = ? AND para = ?)");
            $stmt_delete->bind_param("iiii", $_SESSION['id'], $id, $id, $_SESSION['id']);
            if ($stmt_delete->execute()) {
                // Éxito al dejar de seguir
            } else {
                echo "Error al dejar de seguir: " . $stmt_delete->error;
            }
            $stmt_delete->close();
            header("Location: perfil.php?id=" . $id);
            exit();
        }
    }
?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo htmlspecialchars($use['nombre']); ?> | REDSOCIAL</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
        <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="js/jquery.jscroll.js"></script>
    </head>

    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">

            <?php
            // Pasa la conexión $mysqli a Headerb
            echo Headerb($mysqli);
            echo Side();
            ?>

            <div class="content-wrapper">

                <section class="content">

                    <div class="row">
                        <div class="col-md-3">

                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <img class="profile-user-img img-responsive" src="avatars/<?php echo htmlspecialchars($use['avatar']); ?>" alt="User profile picture">

                                    <h3 class="profile-username text-center"><?php echo htmlspecialchars($use['nombre']); ?></h3>
                                    <?php if ($use['verificado'] != 0) { ?>
                                        <center><span class="glyphicon glyphicon-ok"></span></center>
                                    <?php } ?>

                                    <p class="text-muted text-center">Software Engineer</p>

                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b>Followers</b> <a class="pull-right">1,322</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Following</b> <a class="pull-right">543</a>
                                        </li>
                                        <li class="list-group-item">
                                            <b>Friends</b> <a class="pull-right">13,287</a>
                                        </li>
                                    </ul>

                                    <?php if ($_SESSION['id'] != $id) { // Si es otro usuario 
                                    ?>
                                        <form action="" method="post">
                                            <?php if ($num_amigos >= 1 && $ami['estado'] == 0) { // Solicitud enviada, esperando respuesta 
                                            ?>
                                                <center>
                                                    <h4>Esperando respuesta</h4>
                                                </center>
                                            <?php } else { // No hay solicitud pendiente o ya son amigos 
                                            ?>

                                                <?php if ($use['privada'] == 1 && ($num_amigos == 0 || $ami['estado'] == 0)) { // Perfil privado y NO son amigos o solicitud pendiente 
                                                ?>
                                                    <input type="submit" class="btn btn-primary btn-block" name="seguir" value="Enviar solicitud de amistad">
                                                <?php } ?>

                                                <?php if ($use['privada'] == 1 && $num_amigos >= 1 && $ami['estado'] == 1) { // Perfil privado y YA son amigos 
                                                ?>
                                                    <input type="submit" class="btn btn-danger btn-block" name="dejarseguir" value="Dejar de seguir">
                                                <?php } ?>

                                                <?php if ($use['privada'] == 0 && ($num_amigos == 0 || $ami['estado'] == 0)) { // Perfil público y NO son amigos o solicitud pendiente 
                                                ?>
                                                    <input type="submit" class="btn btn-primary btn-block" name="seguirdirecto" value="Seguir">
                                                <?php } ?>

                                                <?php if ($use['privada'] == 0 && $num_amigos >= 1 && $ami['estado'] == 1) { // Perfil público y YA son amigos 
                                                ?>
                                                    <input type="submit" class="btn btn-danger btn-block" name="dejarseguir" value="Dejar de seguir">
                                                <?php } ?>

                                            <?php } ?>
                                        </form>
                                    <?php } // Fin del if ($_SESSION['id'] != $id) 
                                    ?>

                                    <br>
                                    <a href="chat.php?usuario=<?php echo htmlspecialchars($id); ?>"><input type="button" class="btn btn-default btn-block" value="Enviar chat"></a>

                                </div>
                            </div>
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">About Me</h3>
                                </div>
                                <div class="box-body">
                                    <strong><i class="fa fa-book margin-r-5"></i> Education</strong>
                                    <p class="text-muted">
                                        B.S. in Computer Science from the University of Tennessee at Knoxville
                                    </p>
                                    <hr>
                                    <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>
                                    <p class="text-muted">Malibu, California</p>
                                    <hr>
                                    <strong><i class="fa fa-pencil margin-r-5"></i> Skills</strong>
                                    <p>
                                        <span class="label label-danger">UI Design</span>
                                        <span class="label label-success">Coding</span>
                                        <span class="label label-info">Javascript</span>
                                        <span class="label label-warning">PHP</span>
                                        <span class="label label-primary">Node.js</span>
                                    </p>
                                    <hr>
                                    <strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs">
                                    <li class="<?php echo $pag == 'miactividad' ? 'active' : ''; ?>"><a href="?id=<?php echo htmlspecialchars($id); ?>&perfil=miactividad">Actividad</a></li>
                                    <li class="<?php echo $pag == 'informacion' ? 'active' : ''; ?>"><a href="?id=<?php echo htmlspecialchars($id); ?>&perfil=informacion">Información</a></li>
                                    <li class="<?php echo $pag == 'fotos' ? 'active' : ''; ?>"><a href="?id=<?php echo htmlspecialchars($id); ?>&perfil=fotos">Fotos</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="scroll">

                                        <?php
                                        // ----------------------------------------------------
                                        // Explicación: Lógica para mostrar contenido basado en la privacidad del perfil.
                                        // Se usan los valores de $use['privada'] y $ami['estado'] (de la tabla amigos)
                                        // para determinar qué contenido mostrar.
                                        // La variable $num_amigos se usa para saber si ya existe una relación de amistad.
                                        // ----------------------------------------------------
                                        if (
                                            $use['privada'] != 1 || // Perfil no es privado (público)
                                            ($use['privada'] == 1 && $num_amigos >= 1 && $ami['estado'] == 1) || // Perfil privado y YA son amigos
                                            ($_SESSION['id'] == $id)
                                        ) { // Es el propio usuario

                                            // ----------------------------------------------------
                                            // Explicación: Incluir el contenido de la pestaña activa.
                                            // El nombre del archivo se construye dinámicamente.
                                            // Se usa 'require_once' para asegurar que el archivo se incluya una sola vez.
                                            // Se asegura que el nombre de archivo sea válido para evitar inclusiones maliciosas.
                                            // ----------------------------------------------------
                                            // Lista de páginas permitidas
                                            $valid_pages = ['../config/miactividad.php', 'informacion', 'fotos'];
                                            // Asegura que $pag sea una página válida, si no, usa '../config/miactividad.php'
                                            $current_page = in_array($pag, $valid_pages) ? $pag : '../config/miactividad.php';

                                            // CORRECTO: Solo incluye la página ya determinada en $current_page
                                            require_once $current_page;
                                        } else { // El perfil es privado y el usuario NO es amigo
                                        ?>
                                            <center>
                                                <h2>Este perfil es privado, envía una solicitud.</h2>
                                            </center>
                                        <?php } ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <aside class="control-sidebar control-sidebar-dark">
                <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                    <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
                    <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane" id="control-sidebar-home-tab">
                        <h3 class="control-sidebar-heading">Recent Activity</h3>
                        <ul class="control-sidebar-menu">
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="menu-icon fa fa-birthday-cake bg-red"></i>

                                    <div class="menu-info">
                                        <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                                        <p>Will be 23 on April 24th</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="menu-icon fa fa-user bg-yellow"></i>

                                    <div class="menu-info">
                                        <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                                        <p>New phone +1(800)555-1234</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

                                    <div class="menu-info">
                                        <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                                        <p>nora@example.com</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="menu-icon fa fa-file-code-o bg-green"></i>

                                    <div class="menu-info">
                                        <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                                        <p>Execution time 5 seconds</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <h3 class="control-sidebar-heading">Tasks Progress</h3>
                        <ul class="control-sidebar-menu">
                            <li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Custom Template Design
                                        <span class="label label-danger pull-right">70%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Update Resume
                                        <span class="label label-success pull-right">95%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Laravel Integration
                                        <span class="label label-warning pull-right">50%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Back End Framework
                                        <span class="label label-primary pull-right">68%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
                    <div class="tab-pane" id="control-sidebar-settings-tab">
                        <form method="post">
                            <h3 class="control-sidebar-heading">General Settings</h3>

                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Report panel usage
                                    <input type="checkbox" class="pull-right" checked>
                                </label>

                                <p>
                                    Some information about this general settings option
                                </p>
                            </div>
                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Allow mail redirect
                                    <input type="checkbox" class="pull-right" checked>
                                </label>

                                <p>
                                    Other sets of options are available
                                </p>
                            </div>
                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Expose author name in posts
                                    <input type="checkbox" class="pull-right" checked>
                                </label>

                                <p>
                                    Allow the user to show his name in blog posts
                                </p>
                            </div>
                            <h3 class="control-sidebar-heading">Chat Settings</h3>

                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Show me as online
                                    <input type="checkbox" class="pull-right" checked>
                                </label>
                            </div>
                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Turn off notifications
                                    <input type="checkbox" class="pull-right">
                                </label>
                            </div>
                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Delete chat history
                                    <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </aside>
            <div class="control-sidebar-bg"></div>
        </div>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="plugins/fastclick/fastclick.js"></script>
        <script src="dist/js/app.min.js"></script>
        <script src="dist/js/demo.js"></script>
    </body>

    </html>
<?php
} // finaliza if GET
else {
    // Si no se proporciona un ID de usuario en la URL
    echo "<p style='text-align: center; color: red;'>Error: No se ha especificado un ID de usuario para el perfil.</p>";
    // O redirigir a una página de error o al perfil del usuario logueado
    // header("Location: index.php");
    // exit();
}
?>