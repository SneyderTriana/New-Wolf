<?php
require_once __DIR__ . '/../../config/imagenes.php'; // Importa configuración de rutas de imágenes
require_once __DIR__ . '/../../config/addressDocument.php'; // Importa configuración de rutas de documentos
session_start(); // Inicia la sesión
?>

<body>

    <div class="head"> <!-- Contenedor del encabezado -->
        <div class="logo"> <!-- Sección del logo -->
            <a href="<?= INICIO ?>"> <!-- Enlace a la página de inicio -->
                <figure><img src="<?= LOGO ?>" alt="Logo" height="70px" width="100%" alt="logo"></figure>
                <!-- Imagen del logo -->
            </a>
        </div>

        <nav class="navbar"> <!-- Barra de navegación -->
            <button class="luz"> <!-- Botón de modo claro/oscuro -->
                <figure><img src="<?= LUZ ?>" height="40px" width="40" alt="luz"></figure>
            </button>
            <button class="idioma"> <!-- Botón para cambiar idioma -->
                <figure><img src="<?= IDIOMA ?>" height="40px" width="40" alt="luz"></figure>
            </button>

            <button class="perfil" href="<?= PERFIL ?>">
                <a href="<?= PERFIL ?>?id=<?php echo htmlspecialchars($_SESSION["user"]["id_use"]); ?>">
                    <p><?php echo htmlspecialchars($_SESSION["user"]["username"]); ?></p>
                </a>
                <figure><img src="<?= AVATAR ?>" height="40px" width="40" alt="luz"></figure>
            </button>

            <a href="<?= COMUNIDAD ?>">comunidad</a> <!-- Enlace a comunidad -->
            <a href="<?= TIENDA ?>">tienda</a> <!-- Enlace a tienda -->
            <a href="<?= INFORMACION ?>">informacion</a> <!-- Enlace a información -->
            <a href="<?= CONTACTO ?>">contacto</a> <!-- Enlace a contacto -->

            <?php if (isset($_SESSION["user"]["username"])): ?> <!-- Si el usuario ha iniciado sesión -->
                <p><?php echo htmlspecialchars($_SESSION["user"]["username"]); ?></p> <!-- Muestra el nombre del usuario -->
                <a href="<?= CERRAR ?>" class="btn"><span>Cerrar Sesion</span></a> <!-- Botón para cerrar sesión -->
            <?php else: ?> <!-- Si no hay sesión iniciada -->
                <a href="login.php" class="btn"><span>Iniciar Sesión</span></a> <!-- Botón para iniciar sesión -->
            <?php endif; ?>
        </nav>
    </div>

    <header class="content header"> <!-- Encabezado principal con contenido -->
        <section class="image-gallery"> <!-- Galería de imágenes -->
            <img src="<?= IMAGEN ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN1 ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN2 ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN3 ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN1 ?>" alt="Imagen de galer\u00EDa">
            <img src="<?= IMAGEN2 ?>" alt="Imagen de galer\u00EDa">
        </section>
        <button>
            <span onclick="redirectToinformacion()">Saber Mas </span>
            <!-- Botón para redirigir a sección de información -->
        </button>
    </header>

</body>