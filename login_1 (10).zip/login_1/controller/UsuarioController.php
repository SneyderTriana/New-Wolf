<?php

require_once "model/usuario.php";

class UsuarioController
{
    private $usuarioModel;

    public function __construct()
    {
        $this->usuarioModel = new Usuario();
    }

    public function login($username, $password)
    {
        return $this->usuarioModel->login($username, $password);
    }

    public function registrar($username, $password, $nombre, $correo, $genero, $fechaNacimiento)
    {
        $usuario = new Usuario(); // asegúrate de tener PDO inyectado si se requiere
        return $usuario->registrar($username, $password, $nombre, $correo, $genero, $fechaNacimiento);
    }

}
?>